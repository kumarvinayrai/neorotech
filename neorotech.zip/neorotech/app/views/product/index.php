<?php 
declare(strict_types=1);

// Page Metadata
$bannerImage   = '/assets/images/banner/banner.jpg';
$bannerHeading = 'Shaping Digital for Business Clients';
$bannerText    = 'Creating high-performance digital platforms that solve business challenges and unlock new opportunities!';

// Section Content
$sectionTitle    = 'Created <span>Digital</span> Solutions';
$sectionSubtitle = 'Explore a curated selection of our web design portfolio, demonstrating strategic digital solutions and measurable outcomes that align with business goals across diverse industries through innovation, precision, and a client-centric approach.';

// Portfolio Items
$portfolioItems = [
  [
    'title' => 'Maxearth Solutions',
    'image' => '/assets/images/project/pro-1.png',
    'alt'   => 'Maxearth Solutions Website',
    'url'   => '#'
  ],
  [
    'title' => 'Care Connect',
    'image' => '/assets/images/project/pro-2.png',
    'alt'   => 'Care Connect Website',
    'url'   => '#'
  ],
  [
    'title' => 'Chatbot and AI',
    'image' => '/assets/images/project/pro-3.png',
    'alt'   => 'Chatbot and AI',
    'url'   => '#'
  ],
  [
    'title' => 'School Desk',
    'image' => '/assets/images/project/pro-4.png',
    'alt'   => 'School Desk Website',
    'url'   => '#'
  ]
];

// Includes
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
include __DIR__ . '/../includes/banner.php';
?>

<!-- Portfolio Section --> 
<section id="portfolio" class="position-relative py-5 bg" aria-labelledby="portfolio-heading">
  <div class="container"> 
    <div class="row justify-content-center lead lh-base">
      <div class="col-12 text-center mb-4 aos-init aos-animate" data-aos="fade-up">
        <span class="text-uppercase fw-bold sub-heading-title mb-2">
          Our Portfolio
        </span>
        <?php if (!empty($sectionTitle)): ?>
          <h2 id="portfolio-heading" class="heading-title my-3"><?= $sectionTitle ?></h2>
        <?php endif; ?>
        <?php if (!empty($sectionSubtitle)): ?>
          <p class="mb-4 text-start w-100"><?= htmlspecialchars($sectionSubtitle) ?></p>
        <?php endif; ?>
      </div>
    </div>

    <!-- Portfolio Grid -->
    <div class="row g-4">
      <?php foreach ($portfolioItems as $index => $item): ?>
        <?php if (!empty($item['image']) && !empty($item['title'])): ?>
          <div class="col-12 col-md-6 col-lg-3 d-flex aos-init aos-animate" data-aos="zoom-in" data-aos-delay="<?= $index * 100 ?>">
            <a href="<?= htmlspecialchars($item['url']) ?>" class="text-decoration-none w-100" aria-label="<?= htmlspecialchars($item['title']) ?>">
              <article class="card h-100 w-100 border-0 rounded-0 theme-card d-flex flex-column lead lh-base shadow-sm zoom-effect">
                <img 
                  src="<?= htmlspecialchars($item['image']) ?>" 
                  class="card-img-top img-fluid" 
                  alt="<?= htmlspecialchars($item['alt']) ?>" 
                  loading="lazy"
                  style="border-radius: 0;"
                >
                <div class="card-body text-center">
                  <h6 class="card-title fw-semibold text-dark mb-0"><?= htmlspecialchars($item['title']) ?></h6>
                </div>
                <div class="position-absolute top-0 start-0 w-100 h-100 bg-dark bg-opacity-50 d-flex justify-content-center align-items-center opacity-0 hover-opacity-100 transition">
                  <i class="fa fa-eye text-white fs-4" aria-hidden="true"></i>
                </div>
              </article>
            </a>
          </div>
        <?php endif; ?>
      <?php endforeach; ?>
    </div>

  </div>
</section>

<?php include __DIR__ . '/../includes/footer.php'; ?>
