<?php
$bannerImage = '/assets/images/banner/banner.jpg';
$bannerHeading = 'Contact Us';
$bannerText = 'Have a question or need assistance? Contact us now, and we’ll get back to you promptly!';
$sectionTitle = 'We’re <span>Here </span>to <span>Help </span>You';
$sectionDescription = 'Got a project in mind? We’d love to hear about it. Fill out the form below and let’s talk.';
$contactAddress = 'Wellington Business Park-1, Marol, Andheri East, Mumbai-400059.';
$contactEmail = 'contact@neorotech.com';
$mapQuery = urlencode($contactAddress);

include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
include __DIR__ . '/../includes/banner.php';

$success = '';
$error = '';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
  $name = trim($_POST["name"] ?? '');
  $email = trim($_POST["email"] ?? '');
  $phone = trim($_POST["phone"] ?? '');
  $subject = trim($_POST["subject"] ?? '');
  $message = trim($_POST["message"] ?? '');

  if ($name && filter_var($email, FILTER_VALIDATE_EMAIL) && $phone && $subject && $message) {
    // You can add mail or DB logic here
    $success = "Thank you, $name! Your message has been sent successfully.";
  } else {
    $error = "Please fill out all fields correctly.";
  }
}
?>

<!-- Contact Section -->
<section id="contactUs" aria-labelledby="contact-heading">
  <div class="container py-5">
    <header class="text-center mb-4 lead lh-base">
      <h2 id="contact-heading" class="heading-title my-3" data-aos="fade-up"><?= $sectionTitle ?></h2>
      <p data-aos="fade-up" data-aos-delay="100"><?= htmlspecialchars($sectionDescription) ?></p>
    </header>

    <div class="row gy-4 lead lh-base">
      <!-- Contact Info -->
      <aside class="col-md-4" aria-labelledby="contact-info-heading" data-aos="fade-right">
        <h3 id="contact-info-heading" class="visually-hidden">Contact Information</h3>
        <ul class="list-unstyled">
          <li class="mb-4">
            <h6 class="fw-semibold">Address</h6>
            <p><?= htmlspecialchars($contactAddress) ?></p>
          </li>
          <li>
            <h6 class="fw-semibold">Email Address</h6>
            <p><a href="mailto:<?= htmlspecialchars($contactEmail) ?>" class="text-decoration-none text-dark"><?= htmlspecialchars($contactEmail) ?></a></p>
          </li>
        </ul>
      </aside>

      <!-- Contact Form -->
      <div class="col-md-8" data-aos="fade-left">
        <form method="post" action="#contactUs" class="needs-validation" novalidate aria-labelledby="contact-form-heading">
          <h3 id="contact-form-heading" class="visually-hidden">Contact Form</h3>
          <div class="row g-3">
            <?php
            $fields = [
              ['type' => 'text', 'name' => 'name', 'placeholder' => 'Your Name', 'validation' => 'Please enter your name.'],
              ['type' => 'email', 'name' => 'email', 'placeholder' => 'Email Address', 'validation' => 'Please enter a valid email address.'],
              ['type' => 'text', 'name' => 'phone', 'placeholder' => 'Phone Number', 'validation' => 'Please enter your phone number.'],
              ['type' => 'text', 'name' => 'subject', 'placeholder' => 'Subject', 'validation' => 'Please enter a subject.']
            ];
            foreach ($fields as $field): ?>
              <div class="col-md-6">
                <input
                  type="<?= htmlspecialchars($field['type']) ?>"
                  name="<?= htmlspecialchars($field['name']) ?>"
                  class="form-control"
                  placeholder="<?= htmlspecialchars($field['placeholder']) ?>"
                  required
                  aria-label="<?= htmlspecialchars($field['placeholder']) ?>">
                <div class="invalid-feedback"><?= htmlspecialchars($field['validation']) ?></div>
              </div>
            <?php endforeach; ?>

            <div class="col-12">
              <textarea
                name="message"
                class="form-control"
                rows="5"
                placeholder="Write a message"
                required
                aria-label="Message"></textarea>
              <div class="invalid-feedback">Please enter your message.</div>
            </div>

            <div class="col-12">
              <div class="d-flex justify-content-end">
                <button type="submit" class="btn theme-btn" aria-label="Submit your message">
                  Submit
                </button>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</section>

<!-- Map Section -->
<section aria-label="Location Map" class="pt-0">
  <div class="container-fluid">
    <div class="row">
      <article class="ratio ratio-16x9 shadow-sm overflow-hidden" data-aos="fade-up">
        <iframe
          src="https://www.google.com/maps?q=<?= $mapQuery ?>&output=embed"
          title="Map of <?= htmlspecialchars($contactAddress) ?>"
          loading="lazy"
          referrerpolicy="no-referrer-when-downgrade"
          class="border-0"
          allowfullscreen></iframe>
      </article>
    </div>
  </div>
</section>

<?php include __DIR__ . '/../includes/footer.php'; ?>

<!-- Toast Notification -->
<?php if ($success || $error): ?>
  <div class="position-fixed top-0 start-50 translate-middle-x p-3" style="z-index: 1080;">
    <?php $toastClass = $success ? 'bg-success' : 'bg-danger'; ?>
    <div id="liveToast" class="toast align-items-center text-white <?= $toastClass ?> border-0 show" role="alert" aria-live="assertive" aria-atomic="true">
      <div class="d-flex">
        <div class="toast-body"><?= htmlspecialchars($success ?: $error, ENT_QUOTES, 'UTF-8') ?></div>
        <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
      </div>
    </div>
  </div>
<?php endif; ?>

<!-- Toast & Form Validation Script -->
<script>
(() => {
  'use strict';

  const forms = document.querySelectorAll('.needs-validation');
  forms.forEach(form => {
    form.addEventListener('submit', event => {
      if (!form.checkValidity()) {
        event.preventDefault();
        event.stopPropagation();
      }
      form.classList.add('was-validated');
    });
  });

  document.addEventListener('DOMContentLoaded', () => {
    const toastEl = document.getElementById('liveToast');
    if (toastEl) {
      const toast = new bootstrap.Toast(toastEl, { autohide: true, delay: 5000 });
      toast.show();
    }
  });
})();
</script>
