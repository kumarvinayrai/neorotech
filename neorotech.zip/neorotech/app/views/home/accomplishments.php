<?php
declare(strict_types=1);

$section = [
  'backgroundImage' => '/assets/images/banner/bg-2.jpg',
  'heading'         => 'Project Accomplishments',
  'title'           => 'Delivering <span>Excellence in</span> Every Project',
  'description'     => 'At Neorotech Solutions, we specialize in providing innovative, scalable IT solutions and services that are customized to align with the strategic objectives and evolving operational needs of businesses globally, driving efficiency and technological transformation.',
  'cta'             => ['url' => '/product/index', 'text' => 'Read More'],
  'stats' => [
    ['icon' => 'fa-solid fa-layer-group', 'count' => '04+', 'label' => 'Projects Completed'],
    ['icon' => 'fa-regular fa-face-smile', 'count' => '04+', 'label' => 'Happy Clients'],
    ['icon' => 'fa-solid fa-shield-halved', 'count' => '04+', 'label' => 'Achievements'],
    ['icon' => 'fa-solid fa-stairs', 'count' => '01+', 'label' => 'Years Experience'],
  ],
];
?>

<section
  id="accomplishments"
  class="py-5 bg"
  aria-labelledby="accomplishments-heading"
  style="background: url('<?= htmlspecialchars($section['backgroundImage']) ?>') no-repeat center / cover;"
>
  <div class="container">
    <div class="row align-items-center gy-5 lead lh-base">

      <!-- Text Column -->
      <div class="col-lg-6" data-aos="fade-right">
        <header>
          <span class="text-uppercase fw-bold sub-heading-title mb-2">
            <?= htmlspecialchars($section['heading']) ?>
          </span>
          <h2 id="accomplishments-heading" class="heading-title my-3">
            <?= $section['title'] ?>
          </h2>
        </header>
        <p class="text-muted pe-lg-5">
          <?= htmlspecialchars($section['description']) ?>
        </p>
        <a
          href="<?= htmlspecialchars($section['cta']['url']) ?>"
          class="theme-btn btn mt-3"
          aria-label="Read more about project accomplishments"
        >
          <?= htmlspecialchars($section['cta']['text']) ?>
        </a>
      </div>

      <!-- Stats Column -->
      <div class="col-lg-6" data-aos="fade-left">
        <div class="ms-xl-5">
          <div class="row gy-4">
            <?php foreach ($section['stats'] as $index => $stat): ?>
              <div class="col-12 col-sm-6" data-aos="zoom-in" data-aos-delay="<?= 100 * ($index + 1) ?>">
                <article class="card border-0 rounded-0 h-100 text-center theme-card shadow-sm bg text-dark">
                  <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center py-3">
                      <div class="icon-box">
                        <i class="<?= htmlspecialchars($stat['icon']) ?> fs-1" aria-hidden="true"></i>
                      </div>
                      <span class="fs-1 mx-auto"><?= htmlspecialchars($stat['count']) ?></span>
                    </div>
                    <h5 class="fs-5 py-2 mb-0"><?= htmlspecialchars($stat['label']) ?></h5>
                  </div>
                </article>
              </div>
            <?php endforeach; ?>
          </div>
        </div>
      </div>

    </div>
  </div>
</section>
