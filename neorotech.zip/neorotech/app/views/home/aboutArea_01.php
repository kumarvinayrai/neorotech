<?php

declare(strict_types=1);

$sectionId = 'about';
$sectionClass = 'py-5';

$aboutHeading = [
  'subtitle'   => 'about',
  'title'      => 'We Build Software That <span> Builds Your Businesses.</span>',
  'description' => <<<TEXT
        Neorotech Solutions delivers innovative software development services tailored to meet the evolving needs of modern enterprises. Our offerings include Web Development, UI/UX Design, Mobile App Development, Software Training, DevOps Solutions, and Business Solutions, all crafted to accelerate digital transformation.
        We focus on developing scalable, efficient, and user-focused solutions that drive operational performance and elevate customer engagement, while our collaborative approach ensures alignment with business strategies and market demands.
        Neorotech Solutions empowers organizations to navigate the complexities of digital transformation and achieve long-term success.
    TEXT,
];

$aboutImages = [
  'sideImages' => [
    [
      'src' => '/assets/images/card/card-11.png',
      'alt' => 'Team',
    ],
    [
      'src' => '/assets/images/card/card-12.png',
      'alt' => 'Office',
    ],
  ],
  'mainImage' => [
    'src' => '/assets/images/card/card-1.jpg',
    'alt' => 'Office Team',
  ],
];

$aboutFeatures = [
  [
    'icon'        => '<i class="fa-solid fa-shield-halved fs-1"></i>',
    'title'       => 'Technical Expertise',
    'description' => 'Access to a team of skilled developers, designers, and project managers.',
  ],
  [
    'icon'        => '<i class="fa-solid fa-shield-halved fs-1"></i>',
    'title'       => 'Custom Solutions',
    'description' => 'Development tailored to specific business needs, ensuring better alignment with goals.',
  ],
];

$callToActionText      = 'Learn More';
$callToActionUrl       = '/about/index';
$callToActionIconClass = 'fa-solid fa-arrow-right-long ms-2';

?>

<section id="<?= htmlspecialchars($sectionId) ?>" class="<?= htmlspecialchars($sectionClass) ?>">
  <div class="container">
    <div class="row align-items-center gy-5">

      <!-- Text & Side Images -->
      <div class="col-lg-6" data-aos="fade-right" data-aos-duration="1000">
        <span class="text-uppercase fw-bold sub-heading-title aos-init aos-animate"
          data-aos="fade-up" data-aos-delay="100">
          <?= htmlspecialchars($aboutHeading['subtitle']) ?>
        </span>

        <h2 class="heading-title my-3">
          <?= $aboutHeading['title'] ?>
        </h2>

        <p class="text-muted"><?= nl2br(htmlspecialchars($aboutHeading['description'])) ?></p>

        <div class="row g-3 mt-4">
          <?php foreach ($aboutImages['sideImages'] as $image): ?>
            <div class="col-6">
              <div class="zoom-effect">
                <img src="<?= htmlspecialchars($image['src']) ?>" alt="<?= htmlspecialchars($image['alt']) ?>" class="img-fluid" />
              </div>
            </div>
          <?php endforeach; ?>
        </div>
      </div>

      <!-- Main Image & Features -->
      <div class="col-lg-6" data-aos="fade-left" data-aos-duration="1000">
        <div class="ms-xl-5">
          <div class="zoom-effect">
            <img src="<?= htmlspecialchars($aboutImages['mainImage']['src']) ?>" alt="<?= htmlspecialchars($aboutImages['mainImage']['alt']) ?>" class="img-fluid" />
          </div>
          <?php foreach ($aboutFeatures as $feature): ?>
            <div class="d-flex align-items-start my-3">
              <div class="rounded-icon-container me-3">
                <?= $feature['icon'] ?>
              </div>

              <div>
                <h5 class="fw-semibold mb-1 content-title"><?= htmlspecialchars($feature['title']) ?></h5>
                <p class="mb-0"><?= htmlspecialchars($feature['description']) ?></p>
              </div>
            </div>
          <?php endforeach; ?>
          <a href="<?= htmlspecialchars($callToActionUrl) ?>" class="theme-btn btn mt-3">
            <?= htmlspecialchars($callToActionText) ?>
            <i class="<?= htmlspecialchars($callToActionIconClass) ?>"></i>
          </a>
        </div>
      </div>

    </div>
  </div>
</section>