<?php
declare(strict_types=1);

$section_subtitle = 'What We Do';
$section_title = 'Strategic <span>Software Solutions </span> and expert delivery, on demand';
$section_description = 'At Neorotech Solutions enables organizations to accelerate innovation through scalable, custom-built digital solutions and access to expert development teams on demand and we deliver clarity and value by turning complex problems into reliable, high-performance systems.';

$service_features = [
  [
    'icon_html'   => '<i class="fa-solid fa-code fs-1"></i>',
    'alt_text'    => 'Application Development',
    'title'       => 'Application Development',
    'description' => 'Developing tailored applications that solve real-world challenges and support long-term success.',
  ],
  [
    'icon_html'   => '<i class="fa-solid fa-file-code fs-1"></i>',
    'alt_text'    => 'Software Training',
    'title'       => 'Software Training',
    'description' => 'Providing role-based online software training designed to enhance productivity, optimize workflows, and advance technical proficiency across all user levels.',
  ],
  [
    'icon_html'   => '<i class="fa-solid fa-server fs-1"></i>',
    'alt_text'    => 'DevOps Solutions',
    'title'       => 'DevOps Solutions',
    'description' => 'Modernize software development through DevOps automation to drive faster release cycles, operational efficiency, and strengthened team alignment.',
  ],
  [
    'icon_html'   => '<i class="fa-solid fa-table-cells-row-unlock fs-1"></i>',
    'alt_text'    => 'Business Solutions',
    'title'       => 'Business Solutions',
    'description' => 'Delivering innovative technologies that improve workflows, solve critical challenges, and ensure sustainable business performance.',
  ],
];

$visual_gallery = [
  ['src' => '/assets/images/tech/tech-1.png', 'alt' => 'Team working'],
  ['src' => '/assets/images/tech/tech-2.png', 'alt' => 'Collaboration'],
  ['src' => '/assets/images/tech/tech-3.png', 'alt' => 'UI Design'],
  ['src' => '/assets/images/tech/tech-4.png', 'alt' => 'Workspace'],
];
?>

<section id="whatWeDo" class="py-5" aria-labelledby="whatWeDo-heading">
  <div class="container">
    <div class="row align-items-center lead lh-base g-5">

      <!-- Text Column -->
      <div class="col-lg-6" data-aos="fade-right">
        <header>
          <span class="text-uppercase fw-bold sub-heading-title mb-2">
            <?= htmlspecialchars($section_subtitle) ?>
          </span>
          <h2 id="whatWeDo-heading" class="heading-title my-3">
            <?= $section_title ?>
          </h2>
        </header>
        <p class="my-3">
          <?= htmlspecialchars($section_description) ?>
        </p>

        <!-- Features pe-lg-5-->
        <?php foreach ($service_features as $index => $feature): ?>
          <div class="d-flex align-items-start mb-4" data-aos="fade-up" data-aos-delay="<?= 200 + ($index * 100) ?>">
            <div class="rounded-icon-container me-3">
              <?= $feature['icon_html'] ?>
            </div>
            <div>
              <h5 class="fw-semibold mb-1 content-title"><?= htmlspecialchars($feature['title']) ?></h5>
              <p class="mb-0"><?= htmlspecialchars($feature['description']) ?></p>
            </div>
          </div>
        <?php endforeach; ?>
      </div>

      <!-- Image & Gallery -->
      <div class="col-lg-6" data-aos="fade-left">
        <div class="ms-xl-5">
          
          <!-- Main Image -->
          <figure class="zoom-effect mb-4" data-aos="zoom-in" data-aos-delay="200">
            <img
              src="/assets/images/banner/about-02.jpg"
              alt="Team Collaboration"
              class="img-fluid rounded-0 shadow-sm"
              loading="lazy"
            >
          </figure>

          <!-- Image Grid as Cards -->
          <div class="row g-3">
            <?php foreach ($visual_gallery as $imgIndex => $image): ?>
              <div class="col-6" data-aos="zoom-in" data-aos-delay="<?= 600 + ($imgIndex * 100) ?>">
                <div class="card border-0 shadow-sm h-100">
                  <div class="zoom-effect bg-theme">
                    <img
                      src="<?= htmlspecialchars($image['src']) ?>"
                      alt="<?= htmlspecialchars($image['alt']) ?>"
                      class="img-fluid rounded-0"
                      loading="lazy"
                      width="100%"
                      height="auto"
                    />
                  </div>
                </div>
              </div>
            <?php endforeach; ?>
          </div>

        </div>
      </div>

    </div>
  </div>
</section>
