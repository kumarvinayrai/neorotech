<?php
$clientPartnerLogos = [
  '/assets/images/partner/01.png',
  '/assets/images/partner/02.png',
  '/assets/images/partner/03.png',
  '/assets/images/partner/04.png',
];
?>

<section class="partners py-5 bg" id="partners" aria-labelledby="partnersHeading">
  <div class="container">

    <!-- Section Header -->
    <div class="row lead lh-base">
      <div class="col-12 text-center mb-4" data-aos="fade-up" data-aos-delay="100">
        <span class="text-uppercase fw-bold sub-heading-title">Our Trusted Client</span>
        <h2 class="heading-title my-3" id="partnersHeading">
          Trusted By The <span>Best Agencies</span> In The World
        </h2>
      </div>
    </div>

    <!-- Logo Marquee -->
    <div class="marquee-wrapper overflow-hidden" data-aos="fade-up" data-aos-delay="200">
      <div
        class="marquee d-flex align-items-center"
        id="client-marquee"
        role="region"
        aria-label="Scrolling list of client partner logos"
      >
        <div class="marquee-content d-flex" aria-hidden="false">
          <?php foreach ($clientPartnerLogos as $index => $logoPath): ?>
            <div class="partner-logo mx-3" data-aos="zoom-in" data-aos-delay="<?= 300 + ($index * 100) ?>">
              <img
                src="<?= htmlspecialchars($logoPath, ENT_QUOTES, 'UTF-8') ?>"
                alt="Partner Logo <?= $index + 1 ?>"
                class="img-fluid"
                loading="lazy"
                width="120"
                height="60"
              >
            </div>
          <?php endforeach; ?>
        </div>
        <div class="marquee-content d-flex" aria-hidden="true">
          <?php foreach ($clientPartnerLogos as $index => $logoPath): ?>
            <div class="partner-logo mx-3">
              <img
                src="<?= htmlspecialchars($logoPath, ENT_QUOTES, 'UTF-8') ?>"
                alt=""
                class="img-fluid"
                loading="lazy"
                width="120"
                height="60"
              >
            </div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>

  </div>
</section>

<!-- Marquee JS -->
<script>
  // Optional: enhance with auto-scroll or let CSS handle animation
</script>

<!-- Optional CSS if not already included --> 
