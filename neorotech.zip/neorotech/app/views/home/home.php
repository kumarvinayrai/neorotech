<?php  
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/navbar.php';

require_once __DIR__ . '/carouselSlide.php';
require_once __DIR__ . '/aboutArea.php';

require_once __DIR__ . '/aboutServices.php';
require_once __DIR__ . '/whatwedo.php'; 
require_once __DIR__ . '/ourWork.php';
require_once __DIR__ . '/accomplishments.php';
require_once __DIR__ . '/clientFeedback.php';
require_once __DIR__ . '/partner.php';
require_once __DIR__ . '/../includes/footer.php';
?>
