<?php
declare(strict_types=1);

// Section metadata
$testimonialSection = [
  'subtitle' => 'Client Feedback',
  'title'    => 'Guided by Industry Leaders',
  'image'    => '/assets/images/client/client.jpg',
];

// Testimonials
$testimonials = [
  [
    'quote'  => 'Collaborating with Neorotech Solutions was a smart move for our business...',
    'name'   => 'Sarah Rajesh',
    'role'   => 'IT Executive',
    'rating' => 5,
  ],
  [
    'quote'  => 'Neorotech Solutions has proven to be a reliable long-term partner...',
    'name'   => 'Haresh Bansal',
    'role'   => 'General Manager',
    'rating' => 5,
  ],
  [
    'quote'  => 'Our experience with Neorotech Solutions was seamless and highly productive...',
    'name'   => 'Ranjan Mittal',
    'role'   => 'CEO',
    'rating' => 5,
  ],
];

// Reused images (can be different if desired)
$userImages = array_fill(0, count($testimonials), '/assets/images/client/card-04.png');
?>

<section id="testimonial" class="py-5" aria-labelledby="testimonialHeading">
  <div class="container">
    <div class="row justify-content-center lead lh-base">

      <!-- Section Header -->
      <div class="col-12 text-center mb-4" data-aos="fade-up" data-aos-delay="100">
        <span class="text-uppercase fw-bold sub-heading-title mb-2">
          <?= htmlspecialchars($testimonialSection['subtitle']) ?>
        </span>
        <h2 class="heading-title my-3" id="testimonialHeading">
          <?= htmlspecialchars($testimonialSection['title']) ?>
        </h2>
      </div>

      <!-- Testimonial Carousel -->
      <div class="col-12 col-xl-6 order-xl-1 mb-4" data-aos="fade-right" data-aos-delay="200">
        <div id="testimonialCarousel" class="carousel slide" data-bs-ride="carousel" data-bs-interval="5000" data-bs-pause="hover" aria-describedby="testimonialHeading">
          <div class="carousel-inner">
            <?php foreach ($testimonials as $index => $testimonial): ?>
              <div class="carousel-item <?= $index === 0 ? 'active' : '' ?>" role="group" aria-label="Testimonial <?= $index + 1 ?> of <?= count($testimonials) ?>">
                <div class="p-4 rounded shadow h-100" data-aos="zoom-in" data-aos-delay="100">
                  <blockquote class="blockquote mb-3">
                    <p class="fst-italic">“<?= htmlspecialchars($testimonial['quote']) ?>”</p>
                  </blockquote>
                  <h6 class="fw-bold mb-1 fs-5"><?= htmlspecialchars($testimonial['name']) ?></h6>
                  <small class="text-muted d-block mb-2 fs-6"><?= htmlspecialchars($testimonial['role']) ?></small>

                  <!-- Star Rating -->
                  <div class="text-warning mb-3" aria-label="Rated <?= $testimonial['rating'] ?> out of 5 stars">
                    <?php for ($i = 0; $i < $testimonial['rating']; $i++): ?>
                      <i class="fas fa-star" aria-hidden="true"></i>
                    <?php endfor; ?>
                  </div>

                  <!-- User Images -->
                  <div class="row row-cols-2 row-cols-sm-3 row-cols-md-4 g-3 justify-content-center align-items-center">
                    <?php foreach ($userImages as $imgIndex => $imgUrl): ?>
                      <div class="col text-center">
                        <img
                          src="<?= htmlspecialchars($imgUrl) ?>"
                          alt="Profile image of client <?= $imgIndex + 1 ?>"
                          loading="lazy"
                          style="height: 4.5rem; width: 4.5rem"
                          class="img-fluid rounded-circle <?= $imgIndex === $index ? 'border border-3 border-primary shadow' : '' ?>"
                        >
                      </div>
                    <?php endforeach; ?>
                  </div>
                </div>
              </div>
            <?php endforeach; ?>
          </div>

          <!-- Carousel Indicators -->
          <div class="d-flex justify-content-center mt-4" role="tablist">
            <?php foreach ($testimonials as $index => $_): ?>
              <button
                type="button"
                data-bs-target="#testimonialCarousel"
                data-bs-slide-to="<?= $index ?>"
                class="btn btn-outline-primary mx-1 <?= $index === 0 ? 'active' : '' ?>"
                aria-current="<?= $index === 0 ? 'true' : 'false' ?>"
                aria-label="Go to testimonial <?= $index + 1 ?>">
              </button>
            <?php endforeach; ?>
          </div>
        </div>
      </div>

      <!-- Image Column -->
      <div class="col-12 col-xl-6 order-xl-2 d-flex justify-content-center align-items-center" data-aos="fade-left" data-aos-delay="200">
        <div class="zoom-effect">
          <img
            src="<?= htmlspecialchars($testimonialSection['image']) ?>"
            alt="Client testimonial visual"
            class="img-fluid"
            loading="lazy"
          >
        </div>
      </div>

    </div>
  </div>
</section>

<!-- Accessibility Carousel Sync -->
<script>
  const testimonialCarousel = document.getElementById('testimonialCarousel');
  const indicatorButtons = testimonialCarousel.querySelectorAll('[data-bs-slide-to]');

  testimonialCarousel.addEventListener('slid.bs.carousel', function (event) {
    const activeIndex = event.to;
    indicatorButtons.forEach((btn, idx) => {
      btn.classList.toggle('active', idx === activeIndex);
      btn.setAttribute('aria-current', idx === activeIndex ? 'true' : 'false');
    });
  });
</script>
