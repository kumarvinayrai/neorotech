<?php 
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/navbar.php';

$slides = [
  [
    'image' => '/assets/images/slider/slide3.png',
    'mobileImage' => '/assets/images/slider/slide3-mobile.png',
    'subtitle' => 'Digital Empowering Growth with Us!',
    'title' => 'Transforming <span>Digital Concept</span> into Robust and Profitable Realities.',
    'description' => 'Transforming your businesses through technology that delivers efficiency, resilience, and responsible growth!',
    'buttons' => [
      ['text' => 'Learn More', 'link' => '/about/index', 'icon' => 'fas fa-arrow-right-long']
    ]
  ],
  [
    'image' => '/assets/images/slider/slide4.png',
    'mobileImage' => '/assets/images/slider/slide4-mobile.png',
    'subtitle' => 'Empowering Growth with Nerotech!',
    'title' => 'Results Delivered <span>Nerotech</span> Solutions Provider for Sustainable Growth.',
    'description' => 'We’ve developed impactful software that performs seamlessly and inspires confidence. Let’s explore your investment or quoting needs!',
    'buttons' => [
      ['text' => 'Learn More', 'link' => '/about/index', 'icon' => 'fas fa-arrow-right-long']
    ]
  ]
];
?>

<section class="hero-section slide-bg">
  <div
    id="heroCarousel"
    class="hero-slider hero-theme carousel slide carousel-fade"
    data-bs-ride="carousel"
    data-bs-interval="5000"
    aria-live="polite"
  >

    <!-- Carousel Indicators -->
    <div class="carousel-indicators">
      <?php foreach ($slides as $i => $_): ?>
        <button
          type="button"
          data-bs-target="#heroCarousel"
          data-bs-slide-to="<?= $i ?>"
          class="<?= $i === 0 ? 'active' : '' ?>"
          <?= $i === 0 ? 'aria-current="true"' : '' ?>
          aria-label="Slide <?= $i + 1 ?>"></button>
      <?php endforeach; ?>
    </div>

    <!-- Carousel Slides -->
    <div class="carousel-inner">
      <?php foreach ($slides as $i => $slide): ?>
        <?php
          $isRight = $i % 2 !== 0;
          $justify = $isRight ? 'justify-content-end' : 'justify-content-start';
          $fadeAnim = $isRight ? 'fade-left' : 'fade-right';
          $desktopBg = htmlspecialchars($slide['image']);
          $mobileBg = htmlspecialchars($slide['mobileImage']);
        ?>
        <div class="carousel-item <?= $i === 0 ? 'active' : '' ?>">
          <div
            class="hero-single min-vh-100 d-flex align-items-center lead lh-base bg-cover"
            style="background-image: url('<?= $desktopBg ?>');"
            data-mobile-bg="<?= $mobileBg ?>"
            data-aos="<?= $fadeAnim ?>" data-aos-duration="1000"
          >
            <!-- Preload Image for LCP -->
            <img class="d-none preload" src="<?= $desktopBg ?>" alt="Slide <?= $i + 1 ?>" loading="lazy" />

            <div class="container">
              <div class="row align-items-center <?= $justify ?>">
                <div class="col-lg-7 col-md-12">
                  <div class="hero-content text-start" data-aos="fade-up" data-aos-delay="200">
                    <?php if (!empty($slide['subtitle'])): ?>
                      <h6 class="hero-sub-heading-title mb-2">
                        <?= htmlspecialchars($slide['subtitle']) ?>
                      </h6>
                    <?php endif; ?>

                    <?php if (!empty($slide['title'])): ?>
                      <h1 class="hero-title mb-3">
                        <?= $slide['title'] ?>
                      </h1>
                    <?php endif; ?>

                    <?php if (!empty($slide['description'])): ?>
                      <p class="lead lh-base mb-3">
                        <?= htmlspecialchars($slide['description']) ?>
                      </p>
                    <?php endif; ?>

                    <?php if (!empty($slide['buttons'])): ?>
                      <div class="hero-buttons mt-3 d-flex gap-3 flex-wrap">
                        <?php foreach ($slide['buttons'] as $btn): ?>
                          <a
                            href="<?= htmlspecialchars($btn['link']) ?>"
                            class="theme-btn btn mt-1"
                            data-count="1" <!-- optional for future count-up logic -->
                          >
                            <?= htmlspecialchars($btn['text']) ?>
                            <?php if (!empty($btn['icon'])): ?>
                              <i class="<?= htmlspecialchars($btn['icon']) ?>"></i>
                            <?php endif; ?>
                          </a>
                        <?php endforeach; ?>
                      </div>
                    <?php endif; ?>
                  </div>
                </div>
              </div>
            </div>

          </div>
        </div>
      <?php endforeach; ?>
    </div>

    <!-- Carousel Controls -->
    <button class="carousel-control-prev" type="button" data-bs-target="#heroCarousel" data-bs-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#heroCarousel" data-bs-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Next</span>
    </button>

  </div>
</section>

<style>
  .hero-single {
    background-size: cover;
    background-position: center;
    position: relative;
  }
  @media (max-width: 767.98px) {
    .preload {
      display: none !important;
    }
  }
</style>

<script>
  // Mobile-specific background handling
  document.addEventListener("DOMContentLoaded", function () {
    if (window.innerWidth <= 768) {
      document.querySelectorAll('.hero-single').forEach(function (el) {
        const mobileBg = el.dataset.mobileBg;
        if (mobileBg) {
          el.style.backgroundImage = `url('${mobileBg}')`;
        }
      });
    }
  });

  // Optional: Count-up animation example hook (can be extended with IntersectionObserver)
  document.querySelectorAll('[data-count]').forEach(el => {
    // Placeholder: animate on scroll or on interaction
  });
</script>
