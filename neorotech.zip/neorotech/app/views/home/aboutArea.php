<?php
declare(strict_types=1);

// About section content
$aboutText = [
  'sectionSubtitle' => 'About',
  'sectionTitle'    => 'We Build Software That <span>Builds Your Businesses.</span>',
  'description'     => <<<TEXT
Neorotech Solutions delivers innovative software development services tailored to meet the evolving needs of modern enterprises. Our offerings include Web Development, UI/UX Design, Mobile App Development, Software Training, DevOps Solutions, and Business Solutions, all crafted to accelerate digital transformation.
We focus on developing scalable, efficient, and user-focused solutions that drive operational performance and elevate customer engagement, while our collaborative approach ensures alignment with business strategies and market demands.
Neorotech Solutions empowers organizations to navigate the complexities of digital transformation and achieve long-term success.
TEXT,
];

// About image content
$aboutImageDetails = [
  'imagePath' => '/assets/images/about/about.jpg',
  'imageAlt'  => 'Office Team at Neorotech Solutions',
];

// Call-to-action button
$callToAction = [
  'label'     => 'Learn More',
  'link'      => '/about/index',
  'iconClass' => 'fa-solid fa-arrow-right-long ms-2',
];

// Feature highlight
$featureHighlight = [
  'iconClass' => 'fa-solid fa-shield-halved fs-1',
  'title'     => 'Tech Highlights',
  'details'   => 'Empowering enterprise innovation through a proven and modern technology stack.',
];
?>

<section id="about" class="py-5" aria-labelledby="about-heading">
  <div class="container">
    <div class="row align-items-center lead lh-base g-5">

      <!-- Text Column -->
      <div class="col-lg-6" data-aos="fade-right">
        <header>
          <span class="text-uppercase fw-bold sub-heading-title mb-2">
            <?= htmlspecialchars($aboutText['sectionSubtitle']) ?>
          </span>
          <h2 id="about-heading" class="heading-title my-3">
            <?= $aboutText['sectionTitle'] ?>
          </h2>
        </header>
        <p class="text-muted">
          <?= nl2br(htmlspecialchars($aboutText['description'])) ?>
        </p>
      </div>

      <!-- Image, Feature Highlight, CTA -->
      <div class="col-lg-6" data-aos="fade-left">
        <div class="ms-xl-5">

          <!-- Image Block -->
          <figure class="zoom-effect mb-4" data-aos="zoom-in" data-aos-delay="200">
            <img
              src="<?= htmlspecialchars($aboutImageDetails['imagePath']) ?>"
              alt="<?= htmlspecialchars($aboutImageDetails['imageAlt']) ?>"
              class="img-fluid rounded-0 shadow-sm"
              loading="lazy"
            />
          </figure>

          <!-- Feature Highlight -->
          <div class="d-flex align-items-start mb-3" data-aos="fade-up" data-aos-delay="300">
            <div class="rounded-icon-container me-3">
              <i class="<?= htmlspecialchars($featureHighlight['iconClass']) ?>" aria-hidden="true"></i>
            </div>
            <div>
              <h5 class="mb-1 content-title"><?= htmlspecialchars($featureHighlight['title']) ?></h5>
              <p class="mb-0 pe-lg-5"><?= htmlspecialchars($featureHighlight['details']) ?></p>
            </div>
          </div>

          <!-- CTA Button -->
          <a
            href="<?= htmlspecialchars($callToAction['link']) ?>"
            class="theme-btn btn mt-3"
            aria-label="Learn more about Neorotech"
          >
            <?= htmlspecialchars($callToAction['label']) ?>
            <i class="<?= htmlspecialchars($callToAction['iconClass']) ?>"></i>
          </a>

        </div>
      </div>

    </div>
  </div>
</section>
