<?php
declare(strict_types=1);

// Section content
$projectSection = [
  'subtitle'    => 'Excellence in Scalable Solutions',
  'title'       => 'Why We are <span>Your Trusted</span> Partner',
  'description' => 'Innovate and deploy next-generation digital platforms, cultivate multiple revenue sources, and design agile business models to meet evolving market demands, exceed customer expectations, and stimulate sustained growth.',
];

// Project slides (each slide has 3 projects)
$projectSlides = [
  [
    [
      'title'       => 'Comprehensive Web Solutions',
      'description' => 'Our comprehensive web services cover every aspect of your online presence and delivering scalable, user-friendly, and robust web applications.',
      'link'        => '#',
    ],
    [
      'title'       => 'Leading Web Development',
      'description' => 'Leading Web Development focused on delivering top-tier, customized solutions and driving digital innovation.',
      'link'        => '#',
    ],
    [
      'title'       => 'Next-Gen Web Technologies',
      'description' => 'We bring cutting-edge knowledge and skills in the latest web technologies and delivering innovative solutions that keep your business ahead of the curve.',
      'link'        => '#',
    ],
  ],
  [
    [
      'title'       => 'Incomparable Service Quality',
      'description' => 'Experience service quality that sets us apart from the competition and driven by a passion for client success and attention to detail.',
      'link'        => '#',
    ],
    [
      'title'       => 'Delivering Trusted Solutions',
      'description' => 'Delivering trusted web solutions for more than 02 years, we empower enterprises with scalable and effective digital services.',
      'link'        => '#',
    ],
    [
      'title'       => 'Strategic Partnerships',
      'description' => 'We focus on strategic partnerships that deliver lasting impact and combining expertise and resources for greater business outcomes.',
      'link'        => '#',
    ],
  ],
];
?>

<section id="projects" class="py-5 bg" aria-labelledby="projects-heading">
  <div class="container">

    <!-- Section Header -->
    <div class="row justify-content-center lead lh-base">
      <div class="col-12 text-center mb-4" data-aos="fade-up">
        <span class="text-uppercase fw-bold sub-heading-title mb-2">
          <?= htmlspecialchars($projectSection['subtitle']) ?>
        </span>
        <h2 id="projects-heading" class="heading-title my-3">
          <?= $projectSection['title'] ?>
        </h2>
        <div class="col-12">
          <p class="mb-4 text-start w-100">
            <?= htmlspecialchars($projectSection['description']) ?>
          </p>
        </div>
      </div>
    </div>

    <!-- Carousel -->
    <div id="projectCarousel" class="carousel slide" data-bs-ride="carousel" data-bs-interval="5000" aria-label="Project highlights carousel">
      <div class="carousel-inner">
        <?php foreach ($projectSlides as $slideIndex => $projectGroup): ?>
          <div class="carousel-item <?= $slideIndex === 0 ? 'active' : '' ?>">
            <div class="row g-4">
              <?php foreach ($projectGroup as $projectIndex => $project): ?>
                <div class="col-12 col-sm-6 col-lg-4 d-flex" data-aos="zoom-in" data-aos-delay="<?= 100 * ($projectIndex + 1) ?>">
                  <a href="<?= htmlspecialchars($project['link']) ?>" class="text-decoration-none w-100" aria-label="<?= htmlspecialchars($project['title']) ?>">
                    <article class="card h-100 w-100 border-0 rounded-0 theme-card p-3 d-flex flex-column lead lh-base shadow-sm">
                      <?php if (!empty($project['image'])): ?>
                        <img
                          src="<?= htmlspecialchars($project['image']) ?>"
                          class="card-img-top img-fluid mb-3"
                          alt="<?= htmlspecialchars($project['alt'] ?? $project['title']) ?>"
                          loading="lazy"
                        >
                      <?php endif; ?>
                      <div class="card-body d-flex flex-column">
                        <h3 class="card-title fs-5"><?= htmlspecialchars($project['title']) ?></h3>
                        <p class="card-text text-start"><?= htmlspecialchars($project['description']) ?></p>
                      </div>
                    </article>
                  </a>
                </div>
              <?php endforeach; ?>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    </div>

  </div>
</section>
