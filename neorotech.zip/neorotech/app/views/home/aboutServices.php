<?php
declare(strict_types=1);

// Section header
$servicesHeader = [
  'subtitle'    => 'Who We Are',
  'title'       => 'Explore <span> End-to-End Tech </span> Enablement',
  'description' => 'We deliver technology services that blend innovation with efficiency, specializing in responsive Web and Mobile App Development, refined UI/UX design, customized training, DevOps deployment, and strategic advisory. Our mission is to empower businesses to thrive in today’s dynamic digital landscape.',
];

// Carousel content: services grouped by slide
$carouselServiceSlides = [
  [
    [
      'title'       => 'Web Development',
      'description' => 'Equipping businesses with innovative web solutions that convert ideas into effortless digital interactions.',
      'link'        => '#',
    ],
    [
      'title'       => 'UI/UX Designer',
      'description' => 'Delivering smart, user-focused design solutions that drive engagement and elevate your brand identity.',
      'link'        => '#',
    ],
    [
      'title'       => 'Mobile App Development',
      'description' => 'Developing responsive, engaging mobile experiences that add value for users and raise brand visibility.',
      'link'        => '#',
    ],
  ],
  [
    [
      'title'       => 'Software Training',
      'description' => 'Delivering role-based online software training for all users to improve productivity, streamline workflows, and deepen technical expertise.',
      'link'        => '#',
    ],
    [
      'title'       => 'DevOps Solutions',
      'description' => 'Modernize your development process with DevOps automation that boosts speed, efficiency, and team synergy.',
      'link'        => '#',
    ],
    [
      'title'       => 'Business Solutions',
      'description' => 'Empowering businesses through innovative tools that solve challenges, streamline workflows, and deliver tangible results.',
      'link'        => '#',
    ],
  ],
];
?>

<section id="services" class="py-5 bg" aria-labelledby="services-heading">
  <div class="container">

    <!-- Section Header -->
    <div class="row justify-content-center lead lh-base">
      <div class="col-12 text-center mb-4" data-aos="fade-up">
        <span class="text-uppercase fw-bold sub-heading-title mb-2">
          <?= htmlspecialchars($servicesHeader['subtitle']) ?>
        </span>
        <h2 id="services-heading" class="heading-title my-3">
          <?= $servicesHeader['title'] ?>
        </h2>
        <div class="col-12">
          <p class="mb-4 text-start w-100">
            <?= htmlspecialchars($servicesHeader['description']) ?>
          </p>
        </div>
      </div>
    </div>

    <!-- Carousel -->
    <div id="servicesCarousel" class="carousel slide" data-bs-ride="carousel" data-bs-interval="5000" aria-label="Our services carousel">
      <div class="carousel-inner">
        <?php foreach ($carouselServiceSlides as $slideIndex => $serviceGroup): ?>
          <div class="carousel-item <?= $slideIndex === 0 ? 'active' : '' ?>">
            <div class="row g-4">
              <?php foreach ($serviceGroup as $serviceIndex => $service): ?>
                <div class="col-12 col-sm-6 col-lg-4 d-flex" data-aos="zoom-in" data-aos-delay="<?= 100 * ($serviceIndex + 1) ?>">
                  <a href="<?= htmlspecialchars($service['link']) ?>" class="text-decoration-none w-100" aria-label="<?= htmlspecialchars($service['title']) ?>">
                    <article class="card h-100 w-100 border-0 rounded-0 theme-card p-3 d-flex flex-column lead lh-base shadow-sm">
                      <?php if (!empty($service['imageSrc'])): ?>
                        <img
                          src="<?= htmlspecialchars($service['imageSrc']) ?>"
                          class="card-img-top img-fluid mb-3"
                          alt="<?= htmlspecialchars($service['imageAlt'] ?? $service['title']) ?>"
                          loading="lazy"
                        >
                      <?php endif; ?>
                      <div class="card-body d-flex flex-column">
                        <h3 class="card-title fs-5"><?= htmlspecialchars($service['title']) ?></h3>
                        <p class="card-text text-start"><?= htmlspecialchars($service['description']) ?></p>
                      </div>
                    </article>
                  </a>
                </div>
              <?php endforeach; ?>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    </div>

  </div>
</section>
