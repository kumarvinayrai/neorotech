<?php

declare(strict_types=1);

// Page Meta
$bannerImage   = '/assets/images/banner/banner-01.jpg';
$bannerHeading = 'Responsive Website Design';
$bannerText    = 'Building Adaptive, Mobile-Friendly Websites to Enhance User Experience and Drive Business Results.';

// Includes
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
include __DIR__ . '/../includes/banner.php';

// Intro Data
$servicesData = [
    'sectionId'    => 'responsive-website-design',
    'title'        => 'Responsive Design for Seamless <span>Multi-Device Experiences</span>',
    'introParas'   => [
        'In today’s mobile-first world, a responsive website is essential. Our responsive website design services ensure that your website looks and functions beautifully on any device, from desktops and laptops to tablets and smartphones.',
        ' By using fluid grids, flexible images, and CSS media queries, we create websites that automatically adapt to various screen sizes and orientations, providing users with a consistent experience. This approach not only improves user engagement but also positively impacts your search engine ranking, as responsive design is a key factor for SEO.',
    ]
];
?>

<!-- Website Maintenance & Support Section -->
<section id="<?= htmlspecialchars($servicesData['sectionId']) ?>" class="position-relative py-5" aria-labelledby="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading">
    <div class="container">
        <div class="row align-items-center g-5 lead lh-base">

            <!-- Title Section -->
            <div class="col-lg-5" data-aos="fade-right">
                <header>
                    <h1 id="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading" class="heading-title my-3 h2 fw-bold">
                        <?= $servicesData['title'] ?>
                    </h1>
                </header>
            </div>

            <!-- Description Section -->
            <div class="col-lg-7" data-aos="fade-left" data-aos-delay="100">
                <?php foreach ($servicesData['introParas'] as $para): ?>
                    <p class="text-muted"><?= $para ?></p>
                <?php endforeach; ?>
            </div>

        </div>
    </div>
</section>

<?php include __DIR__ . '/web-development-services.php'; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
