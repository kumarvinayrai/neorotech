<?php

declare(strict_types=1);

// Page Meta
$bannerImage   = '/assets/images/banner/banner-01.jpg';
$bannerHeading = 'UI/UX Audits & Enhancements';
$bannerText    = 'UI/UX audits identify usability issues, improving design for better user engagement, experience, and conversions.';

// Includes
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
include __DIR__ . '/../includes/banner.php';

// Intro Data
$servicesData = [
    'sectionId'    => 'ui-ux-audits-enhancements', 
    'title'        => 'Strategic UI/UX Audits and <span>Enhancements for Every Platform</span>',
    'introParas'   => [
        'Our UI/UX audits evaluate your existing designs to identify usability and engagement issues.',
        'We offer actionable insights to enhance your digital interfaces, optimizing user experience and improving conversion rates.',
        'Regular audits and enhancements ensure that your product stays competitive, meets evolving user needs, and delivers a superior experience.'
    ]
];
?>

<!-- UI/UX Audits & Enhancements Section -->
<section id="<?= htmlspecialchars($servicesData['sectionId']) ?>" class="position-relative py-5" aria-labelledby="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading">
    <div class="container">
        <div class="row align-items-center g-5 lead lh-base">
            <div class="col-lg-5" data-aos="fade-right">
                <header>
                    <h2 id="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading" class="heading-title my-3">
                        <?= $servicesData['title'] ?>
                    </h2>
                </header>
            </div>
            <div class="col-lg-7" data-aos="fade-left" data-aos-delay="100">
                <?php foreach ($servicesData['introParas'] as $para): ?>
                    <p class="text-muted"><?= $para ?></p>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>
<?php include __DIR__ . '/web-development-services.php'; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>