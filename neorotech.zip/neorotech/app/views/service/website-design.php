<?php

declare(strict_types=1);

// Page Meta
$bannerImage   = '/assets/images/banner/banner-01.jpg';
$bannerHeading = 'Website Design';
$bannerText    = 'We create modern, visually appealing websites that deliver seamless navigation, user retention, and conversion optimization.';

// Includes
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
include __DIR__ . '/../includes/banner.php';

// Intro Data
$servicesData = [
    'sectionId'    => 'website-design',
    'title'        => 'Creative<span>  Web Design Solutions </span>for Every Platform',
    'introParas'   => [
        'Our website design services focus on creating visually engaging, user-friendly websites that stand out.',
        '</br>We prioritize intuitive navigation, responsive design, and fast load times to enhance user experience.',
        '</br>With a focus on both aesthetics and functionality, we help attract visitors, retain users, and drive conversions, ensuring lasting online success.'
    ]
];
?>

<!-- Website Design Section -->
<section id="<?= htmlspecialchars($servicesData['sectionId']) ?>" class="position-relative py-5" aria-labelledby="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading">
    <div class="container">
        <div class="row align-items-center g-5 lead lh-base">
            <div class="col-lg-5" data-aos="fade-right">
                <header>
                    <h2 id="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading" class="heading-title my-3">
                        <?= $servicesData['title'] ?>
                    </h2>
                </header>
            </div>
            <div class="col-lg-7" data-aos="fade-left" data-aos-delay="100">
                <?php foreach ($servicesData['introParas'] as $para): ?>
                    <p class="text-muted"><?= $para ?></p>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>
<?php include __DIR__ . '/web-development-services.php'; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>