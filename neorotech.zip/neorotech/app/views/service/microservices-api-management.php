<?php

declare(strict_types=1);

// Page Meta
$bannerImage   = '/assets/images/banner/banner-01.jpg';
$bannerHeading = 'Microservices & API Management';
$bannerText    = 'Leverage microservices and API management to build scalable, modular applications with seamless integration';

// Includes
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
include __DIR__ . '/../includes/banner.php';

// Intro Data
$servicesData = [
    'sectionId'    => 'microservices-api-management',
    'title'        => 'Scalable Microservices <span>Architecture & Advanced API Management</span>',
    'introParas'   => [
        'Microservices and API management empower your applications to be scalable, flexible, and easy to maintain. We help you break down monolithic systems into smaller, modular services that can be independently developed, deployed, and scaled.',
        'Our API management solutions ensure smooth communication between services and external systems. ',
        'By using microservices architecture, your business can achieve greater agility, reduce complexity, and enhance performance, while API management ensures secure and efficient integration across platforms.'
    ]
];
?>

<!-- Microservices & API Management Section -->
<section id="<?= htmlspecialchars($servicesData['sectionId']) ?>" class="position-relative py-5" aria-labelledby="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading">
    <div class="container">
        <div class="row align-items-center g-5 lead lh-base">
            <div class="col-lg-5" data-aos="fade-right">
                <header>
                    <h2 id="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading" class="heading-title my-3">
                        <?= $servicesData['title'] ?>
                    </h2>
                </header>
            </div>
            <div class="col-lg-7" data-aos="fade-left" data-aos-delay="100">
                <?php foreach ($servicesData['introParas'] as $para): ?>
                    <p class="text-muted"><?= $para ?></p>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>
<?php include __DIR__ . '/web-development-services.php'; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>