<?php

declare(strict_types=1);

// Page Meta
$bannerImage   = '/assets/images/banner/banner-01.jpg';
$bannerHeading = 'Mobile App Development Services';
$bannerText    = 'End-to-End Mobile App Development Services: From Concept to Deployment, We Build Seamless User Experiences.';

// Includes
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
include __DIR__ . '/../includes/banner.php';

// Intro Data
$servicesData = [
    'sectionId'    => 'mobile-app-development-services', 
    'title'        => 'Building Scalable, <span>High-Performance Mobile Apps</span>',
    'introParas'   => [
        'Our Mobile app development services encompass native and cross-platform applications, ensuring high performance across all devices.',
        ' We create custom mobile apps tailored to your business needs, hybrid solutions that blend web and native capabilities, and immersive AR/VR applications to enhance user engagement and provide innovative mobile experiences.',
    ]
];
?>

<!-- Mobile App Development Services Section -->
<section id="<?= htmlspecialchars($servicesData['sectionId']) ?>" class="position-relative py-5" aria-labelledby="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading">
    <div class="container">
        <div class="row align-items-center g-5 lead lh-base">
            <div class="col-lg-5" data-aos="fade-right">
                <header>
                    <h2 id="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading" class="heading-title my-3">
                        <?= $servicesData['title'] ?>
                    </h2>
                </header>
            </div>
            <div class="col-lg-7" data-aos="fade-left" data-aos-delay="100">
                <?php foreach ($servicesData['introParas'] as $para): ?>
                    <p class="text-muted"><?= $para ?></p>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>
<?php include __DIR__ . '/web-development-services.php'; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>