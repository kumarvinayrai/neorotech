<?php

declare(strict_types=1);

// Page Meta
$bannerImage   = '/assets/images/banner/banner-01.jpg';
$bannerHeading = 'AI and Data-Driven Solutions';
$bannerText    = 'AI and data-driven solutions enable insights, automation, and smarter decision-making for businesses.';

// Includes
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
include __DIR__ . '/../includes/banner.php';

// Intro Data
$servicesData = [
    'sectionId'    => 'ai-and-data-driven', 
    'title'        => 'Unlock Insights and <span>Innovation with AI-Powered </span>Data Solutions',
    'introParas'   => [
        'AI and Data-Driven Solutions combine advanced machine learning, artificial intelligence, and data analytics to transform business operations. By leveraging large datasets, these solutions provide actionable insights, enhance decision-making, and enable predictive modeling to drive strategic growth.',
        'AI algorithms automate repetitive tasks, optimize processes, and uncover patterns in data that humans may overlook.',
        'Whether through personalized customer experiences, efficient resource management, or risk prediction, data-driven solutions empower organizations to make informed, data-backed decisions.'
    ]
];
?>

<!-- Website Maintenance Section -->
<section id="<?= htmlspecialchars($servicesData['sectionId']) ?>" class="position-relative py-5" aria-labelledby="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading">
    <div class="container">
        <div class="row align-items-center g-5 lead lh-base">
            <div class="col-lg-5" data-aos="fade-right">
                <header>
                    <h2 id="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading" class="heading-title my-3">
                        <?= $servicesData['title'] ?>
                    </h2>
                </header>
            </div>
            <div class="col-lg-7" data-aos="fade-left" data-aos-delay="100">
                <?php foreach ($servicesData['introParas'] as $para): ?>
                    <p class="text-muted"><?= $para ?></p>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>
<?php include __DIR__ . '/web-development-services.php'; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>