<?php

declare(strict_types=1);

// Page Meta
$bannerImage   = '/assets/images/banner/banner-01.jpg';
$bannerHeading = 'Cloud Monitoring, Optimization & Migration Services';
$bannerText    = 'Optimize cloud performance, monitor resources, and manage migration to ensure efficient, cost- effective cloud operations.';

// Includes
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
include __DIR__ . '/../includes/banner.php';

// Intro Data
$servicesData = [
    'sectionId'    => 'cloud-monitoring-optimization-migration-services',
    'title'        => 'Efficient Cloud <span>Monitoring, Optimization & Migration</span>  Every Platform',
    'introParas'   => [
    'Our cloud monitoring, optimization, and migration services ensure your cloud resources perform at their best. We monitor your cloud environment in real-time, identifying areas for improvement and optimizing resource allocation to reduce costs.',
    'Whether you are migrating to the cloud or enhancing your existing infrastructure, we make the process seamless and efficient.',
    'Our team ensures optimal performance, security, and scalability throughout the entire lifecycle of your cloud operations, driving long-term business success.'
    ]
];
?>

<!-- Cloud Monitoring, Optimization & Migration Services Section -->
<section id="<?= htmlspecialchars($servicesData['sectionId']) ?>" class="position-relative py-5" aria-labelledby="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading">
    <div class="container">
        <div class="row align-items-center g-5 lead lh-base">
            <div class="col-lg-5" data-aos="fade-right">
                <header>
                    <h2 id="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading" class="heading-title my-3">
                        <?= $servicesData['title'] ?>
                    </h2>
                </header>
            </div>
            <div class="col-lg-7" data-aos="fade-left" data-aos-delay="100">
                <?php foreach ($servicesData['introParas'] as $para): ?>
                    <p class="text-muted"><?= $para ?></p>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>
<?php include __DIR__ . '/web-development-services.php'; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>