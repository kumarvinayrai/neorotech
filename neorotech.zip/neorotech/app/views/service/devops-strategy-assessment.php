<?php

declare(strict_types=1);

// Page Meta
$bannerImage   = '/assets/images/banner/banner-01.jpg';
$bannerHeading = 'DevOps Strategy & Assessment';
$bannerText    = 'Streamline workflows and boost productivity with customized DevOps strategies and assessments to improve efficiency.';

// Includes
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
include __DIR__ . '/../includes/banner.php';

// Intro Data
$servicesData = [
    'sectionId'    => 'devops-strategy-assessment',
    'title'        => 'Effective DevOps Strategy and<span> Performance Assessment</span>',
    'introParas'   => [
        'Our DevOps strategy and assessment services evaluate your current workflows and design tailored strategies to optimize your development and operations processes. ',
        '</br>We assess bottlenecks,inefficiencies, and opportunities for automation, helping you implement DevOps best practices. By aligning teams and automating tasks, we improve productivity, reduce errors, and accelerate time-to-market.',
        '</br>Our approach ensures that your development pipeline is efficient, collaborative, and scalable,enabling continuous improvement and faster, higher-quality releases.'
    ]
];
?>

<!-- DevOps Strategy & Assessment Section -->
<section id="<?= htmlspecialchars($servicesData['sectionId']) ?>" class="position-relative py-5" aria-labelledby="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading">
    <div class="container">
        <div class="row align-items-center g-5 lead lh-base">
            <div class="col-lg-5" data-aos="fade-right">
                <header>
                    <h2 id="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading" class="heading-title my-3">
                        <?= $servicesData['title'] ?>
                    </h2>
                </header>
            </div>
            <div class="col-lg-7" data-aos="fade-left" data-aos-delay="100">
                <?php foreach ($servicesData['introParas'] as $para): ?>
                    <p class="text-muted"><?= $para ?></p>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>
<?php include __DIR__ . '/web-development-services.php'; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>