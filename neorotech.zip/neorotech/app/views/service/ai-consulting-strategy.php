<?php

declare(strict_types=1);

// Page Meta
$bannerImage   = '/assets/images/banner/banner-01.jpg';
$bannerHeading = 'AI Consulting & Strategy';
$bannerText    = 'AI Consulting & Strategy Solutions guide businesses in leveraging AI for growth, innovation, and efficiency.';

// Includes
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
include __DIR__ . '/../includes/banner.php';

// Intro Data
$servicesData = [
    'sectionId'    => 'ai-consulting-strategy',
    'title'        => 'Transformative AI strategies for<span> business innovation and efficiency.</span>',
    'introParas'   => [
        'Our AI consulting and strategy services help businesses unlock the potential of artificial intelligence to gain a competitive edge.',
        'We work with you to assess your current capabilities, identify areas where AI can add value, and develop a tailored strategy aligned with your business goals.',
        'Whether it’s automating routine tasks, enhancing customer interactions, or improving data analysis, our team provides insights and guidance on the best AI tools and techniques to maximize impact. We also assist with implementing AI initiatives, training teams, and ensuring smooth integration into existing processes.'
    ]
];
?>

<!-- Website Maintenance Section -->
<section id="<?= htmlspecialchars($servicesData['sectionId']) ?>" class="position-relative py-5" aria-labelledby="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading">
    <div class="container">
        <div class="row align-items-center g-5 lead lh-base">
            <div class="col-lg-5" data-aos="fade-right">
                <header>
                    <h2 id="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading" class="heading-title my-3">
                        <?= $servicesData['title'] ?>
                    </h2>
                </header>
            </div>
            <div class="col-lg-7" data-aos="fade-left" data-aos-delay="100">
                <?php foreach ($servicesData['introParas'] as $para): ?>
                    <p class="text-muted"><?= $para ?></p>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>
<?php include __DIR__ . '/web-development-services.php'; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>