<?php

declare(strict_types=1);

// Page Meta
$bannerImage   = '/assets/images/banner/banner-01.jpg';
$bannerHeading = 'Continuous Integration & Continuous Deployment';
$bannerText    = 'Automate software deployment with CI/CD to accelerate release cycles, improve quality, and ensure reliability.';

// Includes
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
include __DIR__ . '/../includes/banner.php';

// Intro Data
$servicesData = [
    'sectionId'    => 'continuous-integration-continuous-deployment-ci-cd',
    'title'        => 'Seamless Continuous <span>Integration and Deployment</span>  (CI/CD) Every Platform',
    'introParas'   => [
        'Websites require regular updates and monitoring to remain secure, functCI/CD practices automate the software development lifecycle, enabling quicker and more reliable releases. We help you implement continuous integration and continuous deployment pipelines that integrate code changes automatically, test them for quality, and deploy seamlessly.',
        'This reduces manual errors, accelerates development, and ensures high-quality releases.',
        'With our CI/CD services, you can rapidly deliver new features and improvements, allowing your business to stay agile, competitive, and responsive to customer needs.'
    ]
];
?>

<!-- Website Maintenance Section -->
<section id="<?= htmlspecialchars($servicesData['sectionId']) ?>" class="position-relative py-5" aria-labelledby="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading">
    <div class="container">
        <div class="row align-items-center g-5 lead lh-base">
            <div class="col-lg-5" data-aos="fade-right">
                <header>
                    <h2 id="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading" class="heading-title my-3">
                        <?= $servicesData['title'] ?>
                    </h2>
                </header>
            </div>
            <div class="col-lg-7" data-aos="fade-left" data-aos-delay="100">
                <?php foreach ($servicesData['introParas'] as $para): ?>
                    <p class="text-muted"><?= $para ?></p>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>
<?php include __DIR__ . '/web-development-services.php'; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>