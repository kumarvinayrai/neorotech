<?php

declare(strict_types=1);

// Page Meta
$bannerImage   = '/assets/images/banner/banner-01.jpg';
$bannerHeading = 'Web Development Services';
$bannerText    = 'Utilize cutting-edge expertise to develop an app, establish a startup, or create a new solution from the ground up.';

// Includes
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
include __DIR__ . '/../includes/banner.php';

// Intro Data
$servicesData = [
    'sectionId'    => 'web-development',
    'subheading'   => 'Web Development Services',
    'title'        => 'Transform Your Business with<span> Web Development Services</span>',
    'introParas'   => [
        'Our web development services include custom web applications, CMS integration, API development, third-party integrations, and responsive design to deliver exceptional user experiences across all devices.',
        'We also offer website maintenance and support to ensure that your site remains secure, up-to-date, and optimized for performance and scalability.',
    ]
];
?>

<!-- Website Development Section -->
<section id="<?= htmlspecialchars($servicesData['sectionId']) ?>" class="position-relative py-5" aria-labelledby="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading">
    <div class="container">
        <div class="row align-items-center g-5 lead lh-base">

            <!-- Title Column -->
            <div class="col-lg-5" data-aos="fade-right">
                <header>
                    <h2 id="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading" class="heading-title my-3">
                        <?= $servicesData['title'] ?>
                    </h2>

                </header>
            </div>

            <!-- Description Column -->
            <div class="col-lg-7" data-aos="fade-left" data-aos-delay="100">
                <?php foreach ($servicesData['introParas'] as $para): ?>
                    <p class="text-muted"><?= htmlspecialchars($para) ?></p>
                <?php endforeach; ?>
            </div>

        </div>
    </div>
</section>

<?php include __DIR__ . '/web-development-services.php'; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>