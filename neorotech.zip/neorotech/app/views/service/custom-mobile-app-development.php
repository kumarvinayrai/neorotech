<?php

declare(strict_types=1);

// Page Meta
$bannerImage   = '/assets/images/banner/banner-01.jpg';
$bannerHeading = 'Custom Mobile App Development';
$bannerText    = 'Unlock Your Business Potential with Tailored Mobile App Development for Seamless User Experience and Growth.';

// Includes
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
include __DIR__ . '/../includes/banner.php';

// Intro Data
$servicesData = [
    'sectionId'    => 'custom-mobile-app-development',
    'title'        => 'End-to-End IT Services for <span>Web Development</span>',
    'introParas'   => [
        'Our custom mobile app development services cater to businesses with unique requirements that aren’t met by standard solutions. We begin with a thorough understanding of your goals, audience, and processes to design and develop an app that is entirely tailored to your business needs.',
        'From feature design to UI/UX, our custom apps are crafted to align with your brand and deliver a unique value proposition to your users. Whether you need a feature-rich e-commerce app, a productivity tool, or a specialized solution for your industry, our custom approach ensures the app is optimized for your specific objectives.',
    ]
];
?>

<!-- Custom Mobile App Development Section -->
<section id="<?= htmlspecialchars($servicesData['sectionId']) ?>" class="position-relative py-5" aria-labelledby="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading">
    <div class="container">
        <div class="row align-items-center g-5 lead lh-base">
            <div class="col-lg-5" data-aos="fade-right">
                <header>
                    <h2 id="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading" class="heading-title my-3">
                        <?= $servicesData['title'] ?>
                    </h2>
                </header>
            </div>
            <div class="col-lg-7" data-aos="fade-left" data-aos-delay="100">
                <?php foreach ($servicesData['introParas'] as $para): ?>
                    <p class="text-muted"><?= $para ?></p>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>
<?php include __DIR__ . '/web-development-services.php'; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>