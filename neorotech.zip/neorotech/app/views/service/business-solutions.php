<?php

declare(strict_types=1);

// Page Meta
$bannerImage   = '/assets/images/banner/banner-01.jpg';
$bannerHeading = 'Business Solutions';
$bannerText    = 'Optimize operations, enhance efficiency, and drive growth with our comprehensive and tailored business solutions.';

// Includes
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
include __DIR__ . '/../includes/banner.php';

// Intro Data
$servicesData = [
    'sectionId'    => 'business-solutions',
    // 'subheading'   => 'Business Solutions',
    'title'        => 'Transforming businesses with innovative,<span>  tailored solutions</span>',
    'introParas'   => [
        'We offer tailored business solutions to streamline your operations, enhance efficiency, and foster growth. From implementing ERP systems that integrate core business functions to providing CRM solutions for better customer relationship management, we offer everything your business needs.',
        'Our expertise extends to developing SPAs, automating business processes, creating seamless e-commerce platforms, and implementing document management systems. We empower businesses to achieve optimal performance and scale effectively in today’s competitive market.',
    ]
];
?>

<!-- Website Maintenance Section -->
<section id="<?= htmlspecialchars($servicesData['sectionId']) ?>" class="position-relative py-5" aria-labelledby="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading">
    <div class="container">
        <div class="row align-items-center g-5 lead lh-base">
            <div class="col-lg-5" data-aos="fade-right">
                <header>
                    <h2 id="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading" class="heading-title my-3">
                        <?= $servicesData['title'] ?>
                    </h2>
                </header>
            </div>
            <div class="col-lg-7" data-aos="fade-left" data-aos-delay="100">
                <?php foreach ($servicesData['introParas'] as $para): ?>
                    <p class="text-muted"><?= $para ?></p>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>
<?php include __DIR__ . '/web-development-services.php'; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>