<?php

declare(strict_types=1);

// Page Meta
$bannerImage   = '/assets/images/banner/banner-01.jpg';
$bannerHeading = 'Augmented Reality & Virtual Reality Apps';
$bannerText    = 'Transform Ideas into Reality with Innovative AR and VR App Solutions for Businesses and Users.';

// Includes
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
include __DIR__ . '/../includes/banner.php';

// Intro Data
$servicesData = [
    'sectionId'    => 'augmented-reality-virtual-reality-apps',
    'title'        => 'Empower Your Brand with<span> AR/VR Technology</span>',
    'introParas'   => [
        'Augmented Reality (AR) and Virtual Reality (VR) technologies offer immersive and interactive experiences that engage users in unprecedented ways.',
        ' Our AR/VR app development services create captivating, experiential applications for industries such as retail, real estate, education, and entertainment. Using cutting-edge technologies, we design apps that blend digital content with the real world (AR) or create fully immersive virtual environments (VR). These applications are particularly effective for training simulations, virtual tours, and enhancing product experiences, delivering value through innovation and engagement.',
    ]
];
?>

<!-- Augmented Reality & Virtual Reality Apps Section -->
<section id="<?= htmlspecialchars($servicesData['sectionId']) ?>" class="position-relative py-5" aria-labelledby="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading">
    <div class="container">
        <div class="row align-items-center g-5 lead lh-base">
            <div class="col-lg-5" data-aos="fade-right">
                <header>
                    <h2 id="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading" class="heading-title my-3">
                        <?= $servicesData['title'] ?>
                    </h2>
                </header>
            </div>
            <div class="col-lg-7" data-aos="fade-left" data-aos-delay="100">
                <?php foreach ($servicesData['introParas'] as $para): ?>
                    <p class="text-muted"><?= $para ?></p>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>
<?php include __DIR__ . '/web-development-services.php'; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>