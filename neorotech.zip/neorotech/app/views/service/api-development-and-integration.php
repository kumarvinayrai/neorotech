<?php

declare(strict_types=1);

// Page Meta
$bannerImage   = '/assets/images/banner/banner-01.jpg';
$bannerHeading = 'API Development and Integration';
$bannerText    = 'Building Scalable APIs for Streamlined Integration, Automation, and Improved Data Connectivity.';

// Includes
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
include __DIR__ . '/../includes/banner.php';

// Intro Data
$servicesData = [
    'sectionId'    => 'api-development-integration',
    'title'        => 'Seamless API Development and <span>Integration for Business Efficiency</span>',
    'introParas'   => [
        'APIs (Application Programming Interfaces) are the backbone of modern software integration. Our API development and integration services allow different applications to communicate and share data seamlessly, creating an interconnected ecosystem of tools and platforms that streamline operations and enhance productivity. We design and implement secure, robust APIs for new and existing systems, enabling real-time data sharing between applications such as CRMs, ERPs, social media, payment gateways, and more.',
        'Our team adheres to the latest security and data protocols to ensure that sensitive data is protected during API transactions.',
    ]
];
?>

<!-- API Development and Integration Section -->
<section id="<?= htmlspecialchars($servicesData['sectionId']) ?>" class="position-relative py-5" aria-labelledby="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading">
    <div class="container">
        <div class="row align-items-center g-5 lead lh-base">
            <div class="col-lg-5" data-aos="fade-right">
                <header>
                    <h2 id="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading" class="heading-title my-3">
                        <?= $servicesData['title'] ?>
                    </h2>
                </header>
            </div>
            <div class="col-lg-7" data-aos="fade-left" data-aos-delay="100">
                <?php foreach ($servicesData['introParas'] as $para): ?>
                    <p class="text-muted"><?= $para ?></p>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>
<?php include __DIR__ . '/web-development-services.php'; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>