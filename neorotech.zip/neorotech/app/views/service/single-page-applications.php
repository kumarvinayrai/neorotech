<?php

declare(strict_types=1);

// Page Meta
$bannerImage   = '/assets/images/banner/banner-01.jpg';
$bannerHeading = 'Single Page Applications';
$bannerText    = 'Develop fast, dynamic, and responsive single-page applications (SPAs) for a seamless user experience.';

// Includes
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
include __DIR__ . '/../includes/banner.php';

// Intro Data
$servicesData = [
    'sectionId'    => 'single-page-applications', 
    'title'        => 'Transforming User Interactions with<span> Speed and Simplicity</span>',
    'introParas'   => [
        'Single Page Applications (SPAs) deliver faster, more dynamic, and responsive user experiences by loading content on a single page. We specialize in developing SPAs that reduce load times, improve performance, and enhance user interaction.',
        'Whether for e-commerce sites, corporate websites, or social platforms, our SPAs ensure smooth transitions, real-time updates, and a seamless browsing experience. By optimizing for speed and user engagement, we help businesses provide an interactive and modern experience that keeps users engaged and satisfied.',
    ]
];
?>

<!-- Website Maintenance Section -->
<section id="<?= htmlspecialchars($servicesData['sectionId']) ?>" class="position-relative py-5" aria-labelledby="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading">
    <div class="container">
        <div class="row align-items-center g-5 lead lh-base">
            <div class="col-lg-5" data-aos="fade-right">
                <header>
                    <h2 id="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading" class="heading-title my-3">
                        <?= $servicesData['title'] ?>
                    </h2>
                </header>
            </div>
            <div class="col-lg-7" data-aos="fade-left" data-aos-delay="100">
                <?php foreach ($servicesData['introParas'] as $para): ?>
                    <p class="text-muted"><?= $para ?></p>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>
<?php include __DIR__ . '/web-development-services.php'; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>