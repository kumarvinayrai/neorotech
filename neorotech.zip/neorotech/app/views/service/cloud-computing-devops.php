<?php

declare(strict_types=1);

// Page Meta
$bannerImage   = '/assets/images/banner/banner-01.jpg';
$bannerHeading = 'Cloud Computing & DevOps Services';
$bannerText    = 'Empower your business with cloud and DevOps solutions that optimize infrastructure, automate workflows, and ensure security.';

// Includes
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
include __DIR__ . '/../includes/banner.php';

// Intro Data
$servicesData = [
    'sectionId'    => 'cloud-computing-devops',
    'title'        => 'Empower Your Business with<span> Scalable Cloud Computing </span> and DevOps Solutions',
    'introParas'   => [
        'At Sharajman Technologies, we offer cloud computing and DevOps services that optimize infrastructure, enhance deployment speed, and improve security.',
        'Our solutions help streamline your workflows, from cloud setup and management to continuous integration and deployment. We ensure your cloud environment is scalable, reliable, and secure, with automated processes that support innovation and growth.',
        'Let us help you transition to the cloud and implement DevOps best practices to accelerate your software development and deployment cycles.'
    ]
];
?>

<!-- Cloud Computing & DevOps Services Section -->
<section id="<?= htmlspecialchars($servicesData['sectionId']) ?>" class="position-relative py-5" aria-labelledby="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading">
    <div class="container">
        <div class="row align-items-center g-5 lead lh-base">
            <div class="col-lg-5" data-aos="fade-right">
                <header>
                    <h2 id="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading" class="heading-title my-3">
                        <?= $servicesData['title'] ?>
                    </h2>
                </header>
            </div>
            <div class="col-lg-7" data-aos="fade-left" data-aos-delay="100">
                <?php foreach ($servicesData['introParas'] as $para): ?>
                    <p class="text-muted"><?= $para ?></p>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>
<?php include __DIR__ . '/web-development-services.php'; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>