<?php

declare(strict_types=1);

// Page Meta
$bannerImage   = '/assets/images/banner/banner-01.jpg';
$bannerHeading = 'Custom Web Application Development';
$bannerText    = 'Crafting High-Performance Web Apps with Customized Features for Unique Business Needs.';

// Includes
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
include __DIR__ . '/../includes/banner.php';

// Intro Data
$servicesData = [
    'sectionId'    => 'custom-web-application-development',
    'title'        => 'Building Scalable <span>Web Applications for Business Growth</span>',
    'introParas'   => [
        'We specialize in building custom web applications that are uniquely crafted to meet your specific business objectives and challenges.',
        'Our team focuses on understanding your business processes and user expectations to create web solutions that drive efficiency, productivity, and user engagement. Whether it’s an e-commerce platform, customer portal, or a specialized industry-specific tool, we prioritize scalability, security, and seamless user experience to help you achieve a competitive edge. Our development process is collaborative, with regular feedback loops to ensure the final product aligns with your vision and goals.',
    ]
];
?>

<!-- Custom Web Application Development -->
<section id="<?= htmlspecialchars($servicesData['sectionId']) ?>" class="position-relative py-5" aria-labelledby="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading">
    <div class="container">
        <div class="row align-items-center g-5 lead lh-base">
            <div class="col-lg-5" data-aos="fade-right">
                <header>
                    <h2 id="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading" class="heading-title my-3">
                        <?= $servicesData['title'] ?>
                    </h2>
                </header>
            </div>
            <div class="col-lg-7" data-aos="fade-left" data-aos-delay="100">
                <?php foreach ($servicesData['introParas'] as $para): ?>
                    <p class="text-muted"><?= $para ?></p>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>
<?php include __DIR__ . '/web-development-services.php'; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>