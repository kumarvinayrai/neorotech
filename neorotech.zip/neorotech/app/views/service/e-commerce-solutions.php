<?php

declare(strict_types=1);

// Page Meta
$bannerImage   = '/assets/images/banner/banner-01.jpg';
$bannerHeading = 'E-commerce Solutions';
$bannerText    = 'Create tailored e-commerce platforms with seamless checkouts, secure payment gateways, and a user-friendly experience.';

// Includes
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
include __DIR__ . '/../includes/banner.php';

// Intro Data
$servicesData = [
    'sectionId'    => 'e-commerce-solutions', 
    'title'        => 'Boost Your Online Business with<span> E-commerce</span>',
    'introParas'   => [
        'We build custom e-commerce solutions that provide a seamless and secure shopping experience for your customers. From intuitive navigation to secure payment gateways, our platforms are designed to optimize user experience and drive conversions.',
        'We ensure fast loading times, mobile optimization, and smooth checkout processes to boost sales and customer satisfaction. Whether you’re launching a new store or enhancing an existing one, we help create an e-commerce platform that reflects your brand and meets customer expectations.',
    ]
];
?>

<!-- Website Maintenance Section -->
<section id="<?= htmlspecialchars($servicesData['sectionId']) ?>" class="position-relative py-5" aria-labelledby="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading">
    <div class="container">
        <div class="row align-items-center g-5 lead lh-base">
            <div class="col-lg-5" data-aos="fade-right">
                <header>
                    <h2 id="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading" class="heading-title my-3">
                        <?= $servicesData['title'] ?>
                    </h2>
                </header>
            </div>
            <div class="col-lg-7" data-aos="fade-left" data-aos-delay="100">
                <?php foreach ($servicesData['introParas'] as $para): ?>
                    <p class="text-muted"><?= $para ?></p>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>
<?php include __DIR__ . '/web-development-services.php'; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>