<?php

declare(strict_types=1);

// Page Meta
$bannerImage   = '/assets/images/banner/banner-01.jpg';
$bannerHeading = 'Cross-Platform App Development';
$bannerText    = 'Deliver Consistent User Experiences with Cross-Platform App Development for Both iOS and Android Devices.';

// Includes
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
include __DIR__ . '/../includes/banner.php';

// Intro Data
$servicesData = [
    'sectionId'    => 'cross-platform-app-development',
    'title'        => 'Custom Cross-Platform <span>Development for Your Business</span>',
    'introParas'   => [
        'Cross-platform app development is a cost-effective solution that enables apps to run on multiple platforms (iOS, Android, etc.) from a single codebase.',
        'Using frameworks like React Native, Flutter, and Xamarin, our team can create apps that deliver a native-like experience while reducing development time and cost. Cross-platform apps are ideal for businesses aiming to reach a wider audience quickly, as they offer consistent functionality and design across devices, with only minor adjustments needed for each platform.',
    ]
];
?>

<!-- Cross-Platform App Development Section -->
<section id="<?= htmlspecialchars($servicesData['sectionId']) ?>" class="position-relative py-5" aria-labelledby="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading">
    <div class="container">
        <div class="row align-items-center g-5 lead lh-base">
            <div class="col-lg-5" data-aos="fade-right">
                <header>
                    <h2 id="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading" class="heading-title my-3">
                        <?= $servicesData['title'] ?>
                    </h2>
                </header>
            </div>
            <div class="col-lg-7" data-aos="fade-left" data-aos-delay="100">
                <?php foreach ($servicesData['introParas'] as $para): ?>
                    <p class="text-muted"><?= $para ?></p>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>
<?php include __DIR__ . '/web-development-services.php'; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>