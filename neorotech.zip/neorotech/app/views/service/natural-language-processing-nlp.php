<?php

declare(strict_types=1);

// Page Meta
$bannerImage   = '/assets/images/banner/banner-01.jpg';
$bannerHeading = 'Natural Language Processing (NLP)';
$bannerText    = 'Transform unstructured data into actionable insights using advanced Natural Language Processing (NLP) technology';

// Includes
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
include __DIR__ . '/../includes/banner.php';

// Intro Data
$servicesData = [
    'sectionId'    => 'natural-language-processing-nlp',
    'title'        => 'Enhance user interactions using <span> Natural Language Processing solutions</span>',
    'introParas'   => [
        'Our NLP solutions leverage advanced algorithms to enable machines to understand, interpret, and generate human language. From chatbots that can comprehend customer queries to sentiment analysis tools that gauge customer satisfaction, we design NLP systems that enhance communication and decision-making.',
        'Our NLP services can be applied to customer service automation, document analysis, voice recognition, and more, helping you improve customer engagement and streamline workflows.',
    ]
];
?>

<!-- Website Maintenance Section -->
<section id="<?= htmlspecialchars($servicesData['sectionId']) ?>" class="position-relative py-5" aria-labelledby="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading">
    <div class="container">
        <div class="row align-items-center g-5 lead lh-base">
            <div class="col-lg-5" data-aos="fade-right">
                <header>
                    <h2 id="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading" class="heading-title my-3">
                        <?= $servicesData['title'] ?>
                    </h2>
                </header>
            </div>
            <div class="col-lg-7" data-aos="fade-left" data-aos-delay="100">
                <?php foreach ($servicesData['introParas'] as $para): ?>
                    <p class="text-muted"><?= $para ?></p>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>
<?php include __DIR__ . '/web-development-services.php'; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>