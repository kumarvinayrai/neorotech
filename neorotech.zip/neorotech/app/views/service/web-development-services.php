<?php
declare(strict_types=1);

$servicesSectionId = 'our-services';
$techCards = [
  ['title' => 'Responsive Website Design', 'desc' => 'In today’s mobile-first world, a responsive website is essential. Our responsive website design services ensure that your website looks and functions beautifully on any device, from desktops and laptops to tablets and smartphones. By using fluid grids, flexible images.', 'delay' => 100],
  ['title' => 'Third-Party Integrations', 'desc' => 'Extend your website’s functionality and enhance user experience through third-party integrations. Our team can integrate a wide range of third-party tools and services, including payment gateways, CRM systems, email marketing software, social media channels, and analytics platforms.', 'delay' => 200],
  ['title' => 'API Development and Integration', 'desc' => 'APIs (Application Programming Interfaces) are the backbone of modern software integration. Our API development and integration services allow different applications to communicate and share data seamlessly, creating an interconnected ecosystem of tools and platforms that streamline operations and enhance productivity.', 'delay' => 300],
  ['title' => 'Data-Driven Innovation', 'desc' => 'We extract powerful insights from data to create smarter, scalable strategies that unlock growth potential.', 'delay' => 100],
  ['title' => 'CMS Development', 'desc' => 'Our CMS development services enable you to manage and update website content effortlessly, without requiring technical expertise. We work with popular Content Management Systems such as WordPress, Drupal, and Joomla, and also build custom CMS solutions tailored to your needs.', 'delay' => 200],
  ['title' => 'Custom Web Application Development', 'desc' => 'We specialize in building custom web applications that are uniquely crafted to meet your specific business objectives and challenges. Our team focuses on understanding your business processes and user expectations to create web solutions that drive efficiency, productivity.', 'delay' => 300]
];
?>

<!-- Web Development Services Section -->
<section id="<?= htmlspecialchars($servicesSectionId) ?>" class="position-relative py-5 bg" aria-labelledby="<?= htmlspecialchars($servicesSectionId) ?>-heading">
  <div class="container">

    <!-- Section Heading -->
    <div class="row justify-content-center lead lh-base">
      <div class="col-12 text-center mb-4" data-aos="fade-up">
        <span class="text-uppercase fw-bold sub-heading-title mb-2">Our Services</span>
        <h2 class="heading-title my-3">
          End-to-End <span>IT Services</span> for <span>Web Development </span>Services
        </h2>
        <p class="mb-4 text-muted text-start w-100">
          We offer a comprehensive range of IT services designed to help businesses streamline operations, improve efficiency, and drive innovation. Whether you're a small startup or a large enterprise, our solutions are tailored to meet your unique needs and challenges.
        </p>
      </div>
    </div>

    <!-- Cards Grid -->
    <div class="row g-4">
      <?php foreach ($techCards as $card): ?>
        <div class="col-12 col-sm-6 col-lg-4 d-flex" data-aos="zoom-in" data-aos-delay="<?= $card['delay'] ?>">
          <a href="#" class="text-decoration-none w-100" aria-label="<?= htmlspecialchars($card['title']) ?>">
            <article class="card h-100 w-100 border-0 rounded-0 theme-card p-3 d-flex flex-column lead lh-base shadow-sm">
              <div class="card-body d-flex flex-column">
                <h3 class="card-title fs-5 fw-semibold"><?= $card['title'] ?></h3>
                <p class="card-text text-muted text-start"><?= $card['desc'] ?></p>
              </div>
            </article>
          </a>
        </div>
      <?php endforeach; ?>
    </div>

  </div>
</section>
