<?php

declare(strict_types=1);

// Page Meta
$bannerImage   = '/assets/images/banner/banner-01.jpg';
$bannerHeading = 'Third-Party Integrations';
$bannerText    = 'Boost Business Performance through Reliable and Secure Third-Party Integrations and Automation.';

// Includes
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
include __DIR__ . '/../includes/banner.php';

// Intro Data
$servicesData = [
    'sectionId'    => 'Third-Party Integrations', 
    'title'        => 'Enhance Business Systems with <span>Third-Party Integrations</span>',
    'introParas'   => [
        'xtend your website’s functionality and enhance user experience through third-party integrations. Our team can integrate a wide range of third-party tools and services, including payment gateways, CRM systems, email marketing software, social media channels, and analytics platforms. These integrations allow your website to offer more robust features and services without requiring extensive in-house development.',
        'Whether you’re looking to add a booking system, automate customer communication, or incorporate advanced analytics, we handle the technicalities so you can focus on what matters most—growing your business.',
    ]
];
?>

<!-- Third-Party Integrations Section -->
<section id="<?= htmlspecialchars($servicesData['sectionId']) ?>" class="position-relative py-5" aria-labelledby="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading">
    <div class="container">
        <div class="row align-items-center g-5 lead lh-base">
            <div class="col-lg-5" data-aos="fade-right">
                <header>
                    <h2 class="heading-title my-3 h4 fw-bold">
                        Comprehensive <span>Website </span>Third-Party Integrations for <span>Maximum </span>Uptime
                    </h2>
                </header>
            </div>
            <div class="col-lg-7" data-aos="fade-left" data-aos-delay="100">
                <?php foreach ($servicesData['introParas'] as $para): ?>
                    <p class="text-muted"><?= $para ?></p>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>
<?php include __DIR__ . '/web-development-services.php'; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>