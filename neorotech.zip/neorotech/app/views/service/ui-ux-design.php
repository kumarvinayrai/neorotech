<?php

declare(strict_types=1);

// Page Meta
$bannerImage   = '/assets/images/banner/banner-01.jpg';
$bannerHeading = 'UI / UX Design';
$bannerText    = 'We create intuitive UI/UX designs, blending aesthetics and functionality to enhance user satisfaction and engagement.';

// Includes
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
include __DIR__ . '/../includes/banner.php';

// Intro Data
$servicesData = [
    'sectionId'    => 'ui-ux-design',  
    'title'        => 'Enhance User Experience with <span>Expert UI/UX Design Services</span>',
    'introParas'   => [
        'Our UI/UX design services focus on crafting seamless, engaging user experiences. We combine aesthetic appeal with functionality, ensuring that every digital interaction is intuitive, efficient, and user-centered.',
        ' Whether for web or mobile, our designs help boost user satisfaction, enhance brand loyalty, and improve business outcomes.',
    ]
];
?>

<!-- UI/UX Design Services Section -->
<section id="<?= htmlspecialchars($servicesData['sectionId']) ?>" class="position-relative py-5" aria-labelledby="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading">
    <div class="container">
        <div class="row align-items-center g-5 lead lh-base">
            <div class="col-lg-5" data-aos="fade-right">
                <header>
                    <h2 id="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading" class="heading-title my-3">
                        <?= $servicesData['title'] ?>
                    </h2>
                </header>
            </div>
            <div class="col-lg-7" data-aos="fade-left" data-aos-delay="100">
                <?php foreach ($servicesData['introParas'] as $para): ?>
                    <p class="text-muted"><?= $para ?></p>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>
<?php include __DIR__ . '/web-development-services.php'; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>