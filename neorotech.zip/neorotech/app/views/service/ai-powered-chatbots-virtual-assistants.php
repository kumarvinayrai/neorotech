<?php

declare(strict_types=1);

// Page Meta
$bannerImage   = '/assets/images/banner/banner-01.jpg';
$bannerHeading = 'AI-Powered Chatbots & Virtual Assistants';
$bannerText    = 'Develop AI chatbots and virtual assistants to automate customer service and provide efficient, round-the-clock support.';

// Includes
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
include __DIR__ . '/../includes/banner.php';

// Intro Data
$servicesData = [
    'sectionId'    => 'ai-powered-chatbots-virtual-assistants',
    'title'        => 'Enhance user interactions using <span>Natural Language Processing solutions</span>',
    'introParas'   => [
        'We develop AI-powered chatbots and virtual assistants that provide 24/7 support to customers and automate routine interactions. Our chatbots use machine learning and NLP to understand user intent and respond effectively, ensuring seamless and efficient communication.',
        'These virtual assistants can handle inquiries, provide recommendations, and escalate complex issues to human agents when necessary. This automation not only reduces the workload on customer support teams but also enhances customer satisfaction by providing instant responses.',
    ]
];
?>

<!-- Website Maintenance Section -->
<section id="<?= htmlspecialchars($servicesData['sectionId']) ?>" class="position-relative py-5" aria-labelledby="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading">
    <div class="container">
        <div class="row align-items-center g-5 lead lh-base">
            <div class="col-lg-5" data-aos="fade-right">
                <header>
                    <h2 id="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading" class="heading-title my-3">
                        <?= $servicesData['title'] ?>
                    </h2>
                </header>
            </div>
            <div class="col-lg-7" data-aos="fade-left" data-aos-delay="100">
                <?php foreach ($servicesData['introParas'] as $para): ?>
                    <p class="text-muted"><?= $para ?></p>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>
<?php include __DIR__ . '/web-development-services.php'; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>