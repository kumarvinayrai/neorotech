<?php

declare(strict_types=1);

// Page Meta
$bannerImage   = '/assets/images/banner/banner-01.jpg';
$bannerHeading = 'Security Integration (DevSecOps)';
$bannerText    = 'Integrate security at every stage of development to ensure compliance, protection, and secure deployment';

// Includes
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
include __DIR__ . '/../includes/banner.php';

// Intro Data
$servicesData = [
    'sectionId'    => 'security-integration-devsecops',
    'title'        => 'Comprehensive Security <span>Integration with DevSecOps</span>',
    'introParas'   => [
        'DevSecOps integrates security into every phase of the development lifecycle, ensuring your applications are secure from start to finish.',
        'We help embed security practices early in the process, automating security checks, and maintaining compliance.',
        'By incorporating continuous security measures into your CI/CD pipelines, we reduce vulnerabilities and ensure data protection at every stage. Our DevSecOps approach gives you peace of mind, ensuring your software is secure, compliant, and resilient against threats.'
    ]
];
?>

<!-- Security Integration (DevSecOps) Section -->
<section id="<?= htmlspecialchars($servicesData['sectionId']) ?>" class="position-relative py-5" aria-labelledby="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading">
    <div class="container">
        <div class="row align-items-center g-5 lead lh-base">
            <div class="col-lg-5" data-aos="fade-right">
                <header>
                    <h2 id="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading" class="heading-title my-3">
                        <?= $servicesData['title'] ?>
                    </h2>
                </header>
            </div>
            <div class="col-lg-7" data-aos="fade-left" data-aos-delay="100">
                <?php foreach ($servicesData['introParas'] as $para): ?>
                    <p class="text-muted"><?= $para ?></p>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>
<?php include __DIR__ . '/web-development-services.php'; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>