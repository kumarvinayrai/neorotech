<?php

declare(strict_types=1);

// Page Meta
$bannerImage   = '/assets/images/banner/banner-01.jpg';
$bannerHeading = 'AI in IoT (Internet of Things)';
$bannerText    = 'AI in IoT (Internet of Things) Integrate AI with IoT for intelligent automation, real-time data processing, and insights to optimize operations.';

// Includes
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
include __DIR__ . '/../includes/banner.php';

// Intro Data
$servicesData = [
    'sectionId'    => 'ai-in-iot-internet-of-things',
    'title'        => 'AI-driven IoT solutions for<span> real-time data processing</span>',
    'introParas'   => [
        'Combining AI with IoT enables smarter, data-driven decision-making for real-time insights and intelligent automation. By integrating AI with connected devices, we enable real-time data processing, predictive analytics, and autonomous operation of IoT systems.',
        'This can be applied to various sectors, such as smart manufacturing, predictive maintenance, and smart cities, where AI-powered IoT solutions analyze sensor data to optimize processes, reduce downtime, and improve efficiency.',
        ' Our AI in IoT solutions bring a new level of intelligence to your operations, helping you monitor, analyze, and act on data from IoT devices.'
    ]
];
?>

<!-- Website Maintenance Section -->
<section id="<?= htmlspecialchars($servicesData['sectionId']) ?>" class="position-relative py-5" aria-labelledby="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading">
    <div class="container">
        <div class="row align-items-center g-5 lead lh-base">
            <div class="col-lg-5" data-aos="fade-right">
                <header>
                    <h2 id="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading" class="heading-title my-3">
                        <?= $servicesData['title'] ?>
                    </h2>
                </header>
            </div>
            <div class="col-lg-7" data-aos="fade-left" data-aos-delay="100">
                <?php foreach ($servicesData['introParas'] as $para): ?>
                    <p class="text-muted"><?= $para ?></p>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>
<?php include __DIR__ . '/web-development-services.php'; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>