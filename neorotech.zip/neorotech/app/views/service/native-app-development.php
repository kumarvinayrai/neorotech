<?php

declare(strict_types=1);

// Page Meta
$bannerImage   = '/assets/images/banner/banner-01.jpg';
$bannerHeading = 'Native App Development';
$bannerText    = 'Transform Your Ideas into Reality with Native App Development: Fast, Secure, and Scalable Mobile Solutions.';

// Includes
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
include __DIR__ . '/../includes/banner.php';

// Intro Data
$servicesData = [
    'sectionId'    => 'native-app-development',
    'title'        => 'Innovative Native <span>App Development </span>for Every Platform',
    'introParas'   => [
        'Native app development involves creating applications specifically designed for a particular operating system, such as iOS or Android. By building apps using platform-specific languages (Swift or Objective-C for iOS, Java or Kotlin for Android), native apps take full advantage of device capabilities, ensuring high performance, fast load times, and a smooth user experience.',
        'These apps can leverage device hardware and software features, like cameras, GPS, and sensors, providing a seamless, responsive, and reliable experience for users.',
    ]
];
?>

<!-- Website Maintenance Section -->
<section id="<?= htmlspecialchars($servicesData['sectionId']) ?>" class="position-relative py-5" aria-labelledby="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading">
    <div class="container">
        <div class="row align-items-center g-5 lead lh-base">
            <div class="col-lg-5" data-aos="fade-right">
                <header>
                    <h2 id="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading" class="heading-title my-3">
                        <?= $servicesData['title'] ?>
                    </h2>
                </header>
            </div>
            <div class="col-lg-7" data-aos="fade-left" data-aos-delay="100">
                <?php foreach ($servicesData['introParas'] as $para): ?>
                    <p class="text-muted"><?= $para ?></p>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>
<?php include __DIR__ . '/web-development-services.php'; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>