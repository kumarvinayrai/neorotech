<?php

declare(strict_types=1);

// Page Meta
$bannerImage   = '/assets/images/banner/banner-01.jpg';
$bannerHeading = 'Wireframing & Prototyping';
$bannerText    = 'Wireframing and prototyping help visualize a product’s structure and flow, reducing risks before development starts.';

// Includes
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
include __DIR__ . '/../includes/banner.php';

// Intro Data
$servicesData = [
    'sectionId'    => 'wireframing-prototyping',
    'title'        => 'Smart Wireframing and <span> Prototyping for All Platforms</span>',
    'introParas'   => [
        'Wireframing and prototyping are key steps in the design process, allowing us to visualize and test product layouts and functionality.',
        'By creating interactive wireframes and prototypes, we can refine user flow, gather feedback, and ensure alignment before development begins.',
        'This helps minimize risks and ensures a smoother final product.'
    ]
];
?>

<!-- Wireframing & Prototyping Section -->
<section id="<?= htmlspecialchars($servicesData['sectionId']) ?>" class="position-relative py-5" aria-labelledby="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading">
    <div class="container">
        <div class="row align-items-center g-5 lead lh-base">
            <div class="col-lg-5" data-aos="fade-right">
                <header>
                    <h2 id="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading" class="heading-title my-3">
                        <?= $servicesData['title'] ?>
                    </h2>
                </header>
            </div>
            <div class="col-lg-7" data-aos="fade-left" data-aos-delay="100">
                <?php foreach ($servicesData['introParas'] as $para): ?>
                    <p class="text-muted"><?= $para ?></p>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>
<?php include __DIR__ . '/web-development-services.php'; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>