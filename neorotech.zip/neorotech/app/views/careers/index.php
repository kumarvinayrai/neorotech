<?php
require_once __DIR__ . '/jobData.php';

// --- PROCESS JOB SEARCH ---
$searchTerm = $_GET['keywords'] ?? null;
$alertMessage = null;

if ($searchTerm !== null) {
    $searchTerm = trim($searchTerm);
    $openings = getCurrentOpenings();
    $matched = array_filter($openings, fn($job) =>
        stripos($job['title'], $searchTerm) !== false
    );

    if (!empty($matched)) {
        header('Location: currentOpenings');
        exit;
    } else {
        $alertMessage = 'Currently we don’t have an open position for the related skillset.';
    }
}

include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';

$data = [
    'hero' => [
        'title' => 'Careers at <span>Neorotech</span>',
        'description' => 'Neorotech offers high-impact opportunities to solve complex challenges through technology, driving a smarter and more sustainable future for people and the planet.',
        'search_placeholder' => 'Enter your keyword here',
        'search_button' => 'Search Jobs',
        'image' => [
            'src' => '/assets/images/banner/banner.jpg',
            'alt' => 'Team of professionals at Neorotech working together in an office'
        ]
    ],
    'contentSections' => [
        [ 
            'heading' => '<span>Innovating</span> Business Through <span>Strategic</span> Software Intelligence',
            'description' => 'Driving business transformation through intelligent, strategy-driven software solutions, we enable growth with innovative and insightful approaches while empowering enterprises with cutting-edge software intelligence for a lasting strategic advantage.',
            'image' => [
                'src' => '/assets/images/banner/bg-01.jpg',
                'alt' => 'Careers campus talent program'
            ],
            'aos' => [
                'section' => 'fade-up',
                'text' => 'fade-right',
                'image' => 'zoom-in',
                'delay' => 200
            ]
        ]
    ],
    'perks' => [
        '5 Days Working Per Week',
        'Open Work Culture',
        'Performance Appreciation Bonus & Rewards',
        'Employee Upskill Programs',
        'Employee Friendly Leave Policies',
        // 'Family Health Insurance',
        // 'International Exposures',
        'Software Training',
    ],
    'callToAction' => [
        'heading' => 'Careers at <span>Neorotech</span>',
        'label' => 'SEARCH AND APPLY',
        'link' => 'currentOpenings',
        'iconClass' => 'fa-solid fa-arrow-right-long ms-2'
    ],
    'communities' => [
        ['title' => 'Talent community', 'link' => 'applyJob'],
        ['title' => 'Campus communities', 'link' => 'applyJob'],
        ['title' => 'Freelance consultants', 'link' => 'applyJob']
    ]
];
?>

<!-- HERO SECTION -->
<section class="bg-primary-clip" aria-labelledby="careers-heading" data-aos="fade-in">
  <div class="container-fluid p-0">
    <div class="row g-0 min-vh-75 align-items-stretch">
      <div class="col-lg-7 d-flex">
        <div class="d-flex flex-column justify-content-center align-items-center align-items-lg-start text-center text-lg-start w-100 px-4 px-lg-5 py-5 hero-single">
          <header class="hero-content w-100" data-aos="fade-right">
            <h1 id="careers-heading" class="hero-title"><?= $data['hero']['title'] ?></h1>
            <p class="mb-0"><?= $data['hero']['description'] ?></p>
          </header>

          <form action="" method="get" class="row g-2 w-100 mt-3 justify-content-center justify-content-lg-start" role="search" aria-label="Job Search Form" data-aos="fade-up">
            <div class="col-12 col-md-7">
              <label for="job-search" class="visually-hidden">Search job keywords</label>
              <input type="text" name="keywords" id="job-search" class="form-control" placeholder="<?= htmlspecialchars($data['hero']['search_placeholder']) ?>" autocomplete="off" required>
            </div>
            <div class="col-12 col-md-5 d-grid">
              <button type="submit" class="theme-btn btn py-2">
                <?= htmlspecialchars($data['hero']['search_button']) ?>
                <i class="fas fa-arrow-right-long ms-2" aria-hidden="true"></i>
              </button>
            </div>
          </form>
        </div>
      </div>
      <div class="col-lg-5">
        <img src="<?= $data['hero']['image']['src'] ?>" alt="<?= $data['hero']['image']['alt'] ?>" class="img-fluid w-100 h-100 object-fit-cover clip-img" style="min-height: 300px;" loading="lazy" decoding="async">
      </div>
    </div>
  </div>
</section>
 
<?php foreach ($data['contentSections'] as $index => $section): ?>
<section class="py-5" aria-labelledby="section-heading-<?= $index ?>" data-aos="<?= $section['aos']['section'] ?>">
  <div class="container">
    <div class="row align-items-center g-5 lead lh-base">
      <div class="col-lg-6" data-aos="<?= $section['aos']['text'] ?>">
        <header>  
          <h2 id="section-heading-<?= $index ?>" class="heading-title my-3"><?= $section['heading'] ?></h2>
        </header>
        <p><?= $section['description'] ?></p>
      </div>
      <div class="col-lg-6">
        <div class="ms-xl-5">
          <figure class="zoom-effect mb-4" data-aos="<?= $section['aos']['image'] ?>" data-aos-delay="<?= $section['aos']['delay'] ?>">
            <img src="<?= $section['image']['src'] ?>" alt="<?= $section['image']['alt'] ?>" class="img-fluid rounded-0 shadow-sm" loading="lazy" decoding="async">
          </figure>
        </div>
      </div>
    </div>
  </div>
</section>
<?php endforeach; ?>

<!-- PERKS SECTION -->
<section class="py-5 bg" aria-label="Life at Neorotech" data-aos="fade-up">
  <div class="container">
    <div class="row mb-4 text-center lead lh-base">
      <div class="col-12" data-aos="fade-up">
        <h2 class="heading-title my-3">Life at <span>Neorotech</span> Solution</h2>
        <p class="text-start">At the core of our approach is intelligent, strategy-driven software that transforms businesses, fosters growth through innovation, and empowers enterprises with forward-thinking software intelligence.</p>
      </div>
    </div>
    <div class="row g-4">
      <?php foreach ($data['perks'] as $index => $perk): ?>
      <div class="col-12 col-md-6 col-lg-4 d-flex" data-aos="zoom-in" <?= $index ? 'data-aos-delay="' . ($index * 100) . '"' : '' ?>>
        <a href="#" class="text-decoration-none w-100" aria-label="<?= htmlspecialchars($perk) ?>">
          <article class="card h-100 w-100 border-0 rounded-0 theme-card p-3 d-flex flex-column lead lh-base shadow-sm">
            <div class="card-body d-flex flex-column justify-content-center align-items-center">
              <h3 class="card-title fs-5 text-center"><?= htmlspecialchars($perk) ?></h3>
            </div>
          </article>
        </a>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- CALL TO ACTION -->
<section class="py-5 text-center" data-aos="zoom-in">
  <div class="container">
    <h2 class="heading-title my-3"><?= $data['callToAction']['heading'] ?></h2>
    <a href="<?= $data['callToAction']['link'] ?>" class="theme-btn btn" title="<?= $data['callToAction']['label'] ?>">
      <?= $data['callToAction']['label'] ?> <i class="<?= $data['callToAction']['iconClass'] ?>"></i>
    </a>
  </div>
</section>

<!-- COMMUNITIES SECTION -->
<section class="py-5 bg" aria-label="Neorotech Talent Communities" data-aos="fade-up">
  <div class="container">
    <div class="row g-4 justify-content-center">
      <?php foreach ($data['communities'] as $index => $community): ?>
      <div class="col-12 col-md-6 col-lg-4 d-flex" data-aos="zoom-in" <?= $index ? 'data-aos-delay="' . ($index * 100 + 200) . '"' : '' ?>>
        <a href="<?= $community['link'] ?>" class="text-decoration-none w-100" title="<?= htmlspecialchars($community['title']) ?>">
          <article class="card h-100 border-0 rounded-0 theme-card p-3 lead lh-base shadow-sm">
            <div class="card-body d-flex flex-column justify-content-center align-items-center">
              <h3 class="fw-semibold mb-3 content-title"><?= htmlspecialchars($community['title']) ?></h3>
              <span class="btn theme-btn text-uppercase d-inline-flex align-items-center gap-2">
                Join Us <i class="fas fa-arrow-right-long ms-2"></i>
              </span>
            </div>
          </article>
        </a>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<?php include __DIR__ . '/../includes/footer.php'; ?>

<!-- ALERT TOAST -->
<?php if ($alertMessage): ?>
<div class="position-fixed top-0 start-50 translate-middle-x p-3" style="z-index: 1055">
  <div class="toast align-items-center text-bg-warning border-0 show" role="alert" aria-live="assertive" aria-atomic="true">
    <div class="d-flex">
      <div class="toast-body"><?= htmlspecialchars($alertMessage) ?></div>
      <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
    </div>
  </div>
</div>
<script>
  const toast = new bootstrap.Toast(document.querySelector('.toast'), { delay: 5000 });
  toast.show();
</script>
<?php endif; ?>
