<?php
// job_data.php
declare(strict_types=1);

function getJobPositions(): array {
    return [
        'Senior Business Analyst',
        'Marketing - Content Writer',
        'PHP Developer',
        'Senior PHP Developer',
        'QA Engineer',
        'Senior QA Engineer',
        '.Net Developer',
        'Technical Lead',
        'Senior DBA',
        'Database Developer',
        'HTML Developer',
        'Python Developer',
        'WordPress Developer',
        'Business Analyst',
        'Chief of Staff',
        'Business Development - IT',
    ];
}

function getCurrentOpenings(): array {
    return [
        [
            'type' => 'Full Time',
            'title' => 'WordPress Developer',
            'experience' => 'Experience 4+ Years',
        ],
        [
            'type' => 'Full Time',
            'title' => 'Business Analyst',
            'experience' => 'Experience 2 - 4 years',
        ],
        [
            'type' => 'Full Time',
            'title' => 'Chief of Staff',
            'experience' => 'Experience 5 - 10 years',
        ],
        [
            'type' => 'Full Time',
            'title' => 'Business Development - IT',
            'experience' => 'Experience 4 - 12 years',
        ],
    ];
}
