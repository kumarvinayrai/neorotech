<?php  
require_once __DIR__ . '/jobData.php';

// Retrieve job openings
$openings = getCurrentOpenings();
$searchTerm = trim($_GET['keywords'] ?? '');
$filteredOpenings = $searchTerm
  ? array_filter($openings, fn($job) => stripos($job['title'], $searchTerm) !== false)
  : $openings;

// Banner content
$bannerHeading = 'Explore Opportunities at Neorotech';
$bannerText    = 'Discover exciting roles tailored for innovators, developers, and tech leaders across various domains.';
$bannerImage   = '/assets/images/banner/banner.jpg';

$data = [
  'heading' => [
    'heading-title' => 'Current Opportunity at <span>Neorotech</span>',
  ]
];

// Static UI text
$texts = [
  'searchResultPrefix' => 'Search results for',
  'noResultsMessage'   => 'Sorry, we couldn’t find any openings matching',
  'applyButton'        => 'Apply Now',
  'contactPrompt'      => 'Didn’t find what you were looking for?',
  'contactEmail'       => 'hr@neorotech.com',
  'applyLinkBase'      => 'applyJob',
];

include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
include __DIR__ . '/../includes/banner.php';
?>

<main id="main-content" class="bg py-5" role="main">
  <section class="container">

    <!-- Page Header -->
    <header class="text-center mb-5" data-aos="fade-up">
      <h1 class="heading-title my-3"><?= $data['heading']['heading-title'] ?></h1>
      <p><?= htmlspecialchars($bannerText) ?></p>
      <?php if ($searchTerm): ?>
        <p class="text-uppercase fw-bold small text-primary" data-aos="fade-up" data-aos-delay="100">
          <?= htmlspecialchars($texts['searchResultPrefix']) ?> "<strong><?= htmlspecialchars($searchTerm) ?></strong>"
        </p>
      <?php endif; ?>
    </header>

    <!-- Job Listings -->
    <?php if (empty($filteredOpenings)): ?>
      <div class="alert alert-warning text-center" role="alert" data-aos="fade-up" data-aos-delay="150">
        <?= htmlspecialchars($texts['noResultsMessage']) ?> "<strong><?= htmlspecialchars($searchTerm) ?></strong>". 
      </div>
    <?php else: ?>
      <section aria-label="Job Openings List">
        <ul class="list-unstyled">
          <?php foreach ($filteredOpenings as $index => $job): ?>
            <li class="mb-4" data-aos="fade-up" <?= $index ? 'data-aos-delay="' . ($index * 60) . '"' : '' ?>>
              <article 
                class="bg-white p-4 shadow-sm rounded d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center gap-3"
                itemscope itemtype="https://neorotech/careers/currentOpenings"
              >
                <div class="job-info">
                  <span class="text-uppercase fw-bold sub-heading-title fs-6 mb-1" itemprop="employmentType">
                    <?= htmlspecialchars($job['type'] ?? '') ?>
                  </span>
                  <h2 class="h5 fw-bold text-dark mb-1" itemprop="title">
                    <?= htmlspecialchars($job['title'] ?? '') ?>
                  </h2>
                  <p class="mb-0 text-muted small" itemprop="experienceRequirements">
                    <?= htmlspecialchars($job['experience'] ?? '') ?>
                  </p>
                </div>
                <div class="job-action mt-3 mt-md-0" data-aos="zoom-in" data-aos-delay="100">
                  <a 
                    href="<?= htmlspecialchars($texts['applyLinkBase']) ?>?job=<?= urlencode($job['title']) ?>" 
                    class="theme-btn btn"
                    title="Apply for <?= htmlspecialchars($job['title']) ?>"
                    aria-label="Apply for <?= htmlspecialchars($job['title']) ?>"
                    itemprop="url"
                  >
                    <?= htmlspecialchars($texts['applyButton']) ?>
                  </a>
                </div>
              </article>
            </li>
          <?php endforeach; ?>
        </ul>
      </section>
    <?php endif; ?>

    <!-- Contact CTA -->
    <footer class="text-center mt-5 pt-4 border-top" data-aos="fade-up" data-aos-delay="200">
      <p class="text-muted small mb-1"><?= htmlspecialchars($texts['contactPrompt']) ?></p>
      <p class="mb-0">
        <a href="mailto:<?= htmlspecialchars($texts['contactEmail']) ?>" class="fw-semibold text-decoration-none" aria-label="Email <?= htmlspecialchars($texts['contactEmail']) ?>">
          <?= htmlspecialchars($texts['contactEmail']) ?>
        </a>
      </p>
    </footer>

  </section>
</main>

<?php include __DIR__ . '/../includes/footer.php'; ?>
