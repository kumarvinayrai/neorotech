<?php
// URI Helpers (SEO & Clean Paths)
function getCleanUri(): string {
  $uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
  $uri = rtrim($uri, '/');
  return ($uri === '' || $uri === '/' || $uri === '/index') ? '/home/home' : $uri;
}

function activeNav(array|string $paths): string {
  $paths = (array)$paths;
  $current = getCleanUri();
  foreach ($paths as $path) {
    $cleanPath = rtrim($path, '/');
    if ($cleanPath === '' || $cleanPath === '/index') $cleanPath = '/home/home';
    if ($current === $cleanPath || str_starts_with($current, $cleanPath . '/')) {
      return 'active';
    }
  }
  return '';
}

// Main Nav Items
$navItems = [
  ['label' => 'home', 'path' => '/home/home'],
  ['label' => 'about', 'path' => '/about/index'],
  ['label' => 'product', 'path' => '/product/index'],
  ['label' => 'careers', 'path' => '/careers/index'],
  ['label' => 'contact', 'path' => '/contact/index'],
];

// Services Dropdown Menu
$servicesMenu = [
  [
    'category' => 'Web Development',
    'icon' => 'fas fa-code rounded-icon',
    'path' => '/service/web-development/',
    'services' => [
      'Website Maintenance and Support' => '/service/website-maintenance-and-support/',
      'Responsive Website Design' => '/service/responsive-website-design/',
      'Third-Party Integrations' => '/service/third-party-integrations/',
      'API Development and Integration' => '/service/api-development-and-integration/',
      'CMS Development' => '/service/cms-development/',
      'Custom Web App Development' => '/service/custom-web-application-development/',
    ]
  ],
  [
    'category' => 'Mobile App Development',
    'icon' => 'fas fa-mobile-alt rounded-icon',
    'path' => '/service/mobile-app-development/',
    'services' => [
      'AR & VR Apps' => '/service/augmented-reality-virtual-reality-apps/',
      'Hybrid App Development' => '/service/hybrid-mobile-app-development/',
      'Custom Mobile Apps' => '/service/custom-mobile-app-development/',
      'Cross-Platform Apps' => '/service/cross-platform-app-development/',
      'Native App Development' => '/service/native-app-development/',
    ]
  ],
  [
    'category' => 'UI / UX Design',
    'icon' => 'fas fa-pencil-ruler rounded-icon',
    'path' => '/service/ui-ux-design/',
    'services' => [
      'UX Strategy' => '/service/ux-strategy-consulting/',
      'UI/UX Audits' => '/service/ui-ux-audits-enhancements/',
      'Wireframing' => '/service/wireframing-prototyping/',
      'Website Design' => '/service/website-design/',
      'App Design' => '/service/mobile-app-design/',
      'Product Design' => '/service/product-design/',
    ]
  ],
  [
    'category' => 'Cloud & DevOps',
    'icon' => 'fas fa-cloud rounded-icon',
    'path' => '/service/cloud-computing-devops/',
    'services' => [
      'DevOps Strategy' => '/service/devops-strategy-assessment/',
      'Microservices' => '/service/microservices-api-management/',
      'DevSecOps' => '/service/security-integration-devsecops/',
      'CI/CD Pipelines' => '/service/continuous-integration-continuous-deployment-ci-cd/',
      'Cloud Monitoring' => '/service/cloud-monitoring-optimization-migration-services/',
    ]
  ],
  [
    'category' => 'AI & Data',
    'icon' => 'fas fa-robot rounded-icon',
    'path' => '/service/ai-and-data-driven/',
    'services' => [
      'AI in IoT (Internet of Things)' => '/service/ai-in-iot-internet-of-things/',
      'AI-Powered Chatbots & Virtual Assistants' => '/service/ai-powered-chatbots-virtual-assistants/',
      'Natural Language Processing (NLP)' => '/service/natural-language-processing-nlp/',
      'AI Consulting & Strategy' => '/service/ai-consulting-strategy/',
    ]
  ],
  [
    'category' => 'Business Solutions',
    'icon' => 'fas fa-briefcase rounded-icon',
    'path' => '/service/business-solutions/',
    'services' => [
      'Document Management System' => '/service/document-management-systems/',
      'E-Commerce' => '/service/e-commerce-solutions/',
      'Business Process Automation (BPA)' => '/service/business-process-automation-bpa/',
      'Single Page Apps' => '/service/single-page-applications/', 
    ]
  ],
];
?>

<!-- Header Navigation -->
<nav class="navbar navbar-expand-lg navbar-top shadow-sm" data-aos="fade-down">
  <div class="container-fluid px-3 px-lg-5">
    <a class="navbar-brand" href="/home/index">
      <h1 class="h4 m-0 fs-3 fw-bold"><i class="fas fa-code me-2"></i> Neorotech</h1>
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#mobileNav">
      <i class="fa-solid fa-bars toggler-icon"></i>
    </button>

    <!-- Desktop Menu -->
    <div class="collapse navbar-collapse d-none d-lg-flex justify-content-end">
      <ul class="navbar-nav gap-3 align-items-center lead lh-base">
        <?php foreach ($navItems as $index => $item): ?>
          <?php if ($index === 2): ?>
            <li class="nav-item dropdown position-static hover-trigger">
              <a class="nav-link dropdown-toggle-icon <?= activeNav(array_column($servicesMenu, 'path')) ?>" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                Services
                <i class="fa-solid fa-chevron-down fs-12 icon-down"></i>
                <i class="fa-solid fa-chevron-up fs-12 icon-up"></i>
              </a>
              <div class="dropdown-menu w-100 border-0 p-0 mt-0">
                <div class="container py-4">
                  <div class="row g-4">
                    <?php foreach ($servicesMenu as $cat): ?>
                      <div class="col-sm-6 col-lg-4" data-aos="fade-up">
                        <div class="mb-2 d-flex align-items-center">
                          <i class="<?= $cat['icon'] ?> me-2"></i>
                          <a href="<?= htmlspecialchars($cat['path']) ?>" class="fw-semibold text-decoration-none">
                            <?= htmlspecialchars($cat['category']) ?>
                          </a>
                        </div>
                        <ul class="list-unstyled">
                          <?php foreach ($cat['services'] as $lbl => $lnk): ?>
                            <li><a class="dropdown-item ps-4" href="<?= htmlspecialchars($lnk) ?>"><?= htmlspecialchars($lbl) ?></a></li>
                          <?php endforeach; ?>
                        </ul>
                      </div>
                    <?php endforeach; ?>
                  </div>
                </div>
              </div>
            </li>
          <?php endif; ?>
          <li class="nav-item" data-aos="fade-down">
            <a class="nav-link <?= activeNav($item['path']) ?>" href="<?= htmlspecialchars($item['path']) ?>">
              <?= ucfirst(htmlspecialchars($item['label'])) ?>
            </a>
          </li>
        <?php endforeach; ?>
      </ul>
    </div>
  </div>

  <!-- Mobile Offcanvas Nav -->
  <div class="offcanvas offcanvas-end d-lg-none" id="mobileNav">
    <div class="offcanvas-header">
      <a class="navbar-brand" href="/home/index">
        <h1 class="h4 m-0 fs-3 fw-bold"><i class="fas fa-code me-2"></i> Neorotech</h1>
      </a>
      <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas"></button>
    </div>
    <div class="offcanvas-body">
      <ul class="navbar-nav lead lh-base">
        <?php foreach ($navItems as $index => $item): ?>
          <?php if ($index === 2): ?>
            <li class="nav-item">
              <a class="nav-link d-flex justify-content-between collapsed" data-bs-toggle="collapse" href="#mobileServices" role="button" aria-expanded="false">
                Services
                <span>
                  <i class="fa-solid fa-chevron-down fs-12 icon-down"></i>
                  <i class="fa-solid fa-chevron-up fs-12 icon-up d-none"></i>
                </span>
              </a>
              <div class="collapse ps-3" id="mobileServices">
                <?php foreach ($servicesMenu as $cat): ?>
                  <div class="pt-2">
                    <a class="fw-semibold d-block" href="<?= htmlspecialchars($cat['path']) ?>"><?= htmlspecialchars($cat['category']) ?></a>
                    <ul class="list-unstyled ps-2">
                      <?php foreach ($cat['services'] as $lbl => $lnk): ?>
                        <li><a class="d-block py-2" href="<?= htmlspecialchars($lnk) ?>"><?= htmlspecialchars($lbl) ?></a></li>
                      <?php endforeach; ?>
                    </ul>
                  </div>
                <?php endforeach; ?>
              </div>
            </li>
          <?php endif; ?>
          <li class="nav-item" data-aos="fade-up">
            <a class="nav-link <?= activeNav($item['path']) ?>" href="<?= htmlspecialchars($item['path']) ?>" data-bs-dismiss="offcanvas">
              <?= ucfirst(htmlspecialchars($item['label'])) ?>
            </a>
          </li>
        <?php endforeach; ?>
      </ul>
    </div>
  </div>
</nav>

<!-- Chevron Toggle Style -->
<style>
  .dropdown-toggle-icon .icon-up { display: none; }
  .hover-trigger:hover .icon-down { display: none; }
  .hover-trigger:hover .icon-up { display: inline; }
</style>

<!-- Scroll Effects Script -->
<script>
  document.addEventListener('DOMContentLoaded', () => {
    const navbar = document.querySelector('.navbar-top');
    const megaDropdown = document.querySelector('.dropdown-menu.w-100');

    function handleScroll() {
      const scrollY = window.scrollY;
      navbar?.classList.toggle('navbar-fixed', scrollY > 10);
      navbar?.classList.toggle('scrolled', scrollY > 10);
      navbar?.classList.toggle('nav-top', scrollY === 0);
      megaDropdown?.classList.toggle('scrolled-dropdown', scrollY > 10);
    }

    window.addEventListener('scroll', () => requestAnimationFrame(handleScroll));
    handleScroll();
  });
</script>
