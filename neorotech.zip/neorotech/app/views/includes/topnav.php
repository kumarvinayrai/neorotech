<section class="d-none d-xl-block">
  <div class="header-top py-2">
    <div class="container">
      <div class="row header-top-wrapper align-items-center">

        <!-- Left Side -->
        <div class="col-lg-9 header-top-left">
          <div class="header-top-contact">
            <ul class="list-unstyled d-flex flex-wrap align-items-center m-0">
              <li class="me-4">
                <a href="#" class="d-inline-flex align-items-center">
                  <i class="fa-solid fa-location-dot me-1"></i>
                  Wellington Business Park-1 Andheri East, Mumbai-400059
                </a>
              </li>
              <li class="me-4">
                <a href="mailto:support@maxearth.com" class="d-inline-flex align-items-center">
                  <i class="fa-solid fa-envelope me-1"></i>
                  support@ Neorotech.com
                </a>
              </li>
              <li>
                <a href="tel:+919819956751" class="d-inline-flex align-items-center">
                  <i class="fa-solid fa-phone-volume me-1"></i>
                  +91 9819956751
                </a>
              </li>
            </ul>
          </div>
        </div>

        <!-- Right Side -->
        <div class="col-lg-3 header-top-left">
          <div class="header-top-social d-flex justify-content-lg-end align-items-center">
            <a href="https://facebook.com" target="_blank" class="me-2"><i class="fa-brands fa-facebook"></i></a>
            <a href="https://x.com" target="_blank" class="me-2"><i class="fa-brands fa-x-twitter"></i></a>
            <a href="https://instagram.com" target="_blank" class="me-2"><i class="fa-brands fa-instagram"></i></a>
            <a href="https://linkedin.com" target="_blank"><i class="fa-brands fa-linkedin"></i></a>
          </div>
        </div>

      </div>
    </div>
  </div>
</section>
