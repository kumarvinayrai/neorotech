<?php
if (!defined('BASE_URL')) define('BASE_URL', '/');

$contact = [
  'phone' => '+91 9819956751',
  'email' => 'info@neorotech.com',
  'address' => 'Wellington Business Park-1 Marol, Andheri East, Mumbai-400059.'
];

$quickLinks = [
  ['Home', 'home/home'],
  ['About', 'about/index'],
  ['Services', 'services/index'],
  ['Product', 'product/index'],
  ['Careers', 'careers/index'],
  ['Contact Us', 'contact/index'],
];

$social = [
  'facebook' => 'https://facebook.com',
  'x-twitter' => 'https://twitter.com',
  'youtube' => 'https://www.youtube.com/',
  'linkedin-in' => 'https://www.linkedin.com/',
];
?>

<section class="footer-area pt-5" aria-label="Footer Section">
  <footer class="footer-content">
    <div class="container">
      <div class="row gy-4 lead lh-base">

        <div class="col-md-6 col-lg-4 footer-content-box" data-aos="fade-right">
          <a href="<?= BASE_URL ?>" class="footer-logo d-inline-block py-3" aria-label="Go to homepage">
            <h1 class="h4 m-0 text-white">
              <i class="fas fa-code me-2" aria-hidden="true"></i> Neorotech
            </h1>
          </a>
          <p class="mb-3">We are a software development company specializing in designing, developing, and deploying software applications.</p>
          <ul class="footer-contact list-unstyled">
            <li>
              <a href="tel:<?= $contact['phone'] ?>" aria-label="Call us at <?= $contact['phone'] ?>">
                <i class="fa-solid fa-phone"></i> <?= $contact['phone'] ?>
              </a>
            </li>
            <li>
              <i class="fa-solid fa-location-dot" aria-hidden="true"></i> <?= $contact['address'] ?>
            </li>
            <li>
              <a href="mailto:<?= $contact['email'] ?>" aria-label="Email us at <?= $contact['email'] ?>">
                <i class="fa-solid fa-envelope"></i> <?= $contact['email'] ?>
              </a>
            </li>
          </ul>
        </div>

        <div class="col-md-12 col-lg-4" data-aos="fade-up">
          <h5 class="footer-content-title">Quick Links</h5>
          <div class="row">
            <?php $half = ceil(count($quickLinks) / 2);
            $chunks = array_chunk($quickLinks, $half); ?>
            <?php foreach ($chunks as $chunk): ?>
              <div class="col-6">
                <ul class="footer-list list-unstyled">
                  <?php foreach ($chunk as [$label, $url]): ?>
                    <li>
                      <a href="<?= BASE_URL . $url ?>" aria-label="<?= $label ?>">
                        <i class="fas fa-caret-right"></i> <?= $label ?>
                      </a>
                    </li>
                  <?php endforeach; ?>
                </ul>
              </div>
            <?php endforeach; ?>
          </div>
        </div>

        <div class="col-md-6 col-lg-4" data-aos="fade-up">
          <h5 class="footer-content-title">Join Our Newsletter</h5>
          <p class="py-3">Stay updated with our latest news and offers.</p>
          <form id="newsletterForm" class="subscribe-form" novalidate>
            <label for="newsletter-email" class="visually-hidden">Email Address</label>
            <input type="email" name="email" id="newsletter-email" class="form-control" placeholder="Your Email" required>
            <button class="theme-btn mt-2" type="submit">
              Subscribe Now <i class="fa-solid fa-paper-plane ms-2"></i>
            </button>
          </form>
        </div>

      </div>
    </div>

    <div class="copyright lead lh-base mt-4">
      <div class="container">
        <div class="row">
          <div class="col-md-6" data-aos="fade-up">
            <p class="copyright-text">
              &copy; 2025 Neorotech Solutions PVT. LTD. All Rights Reserved.<br>
              Powered by <a href="<?= BASE_URL ?>" aria-label="Visit Neorotech homepage">Neorotech Solutions Pvt Ltd.</a>
            </p>
          </div>
          <div class="col-md-6 d-flex justify-content-md-end justify-content-center align-items-center aos-init aos-animate" data-aos="fade-up" data-aos-delay="100">
            <ul class="footer-social list-inline mb-0 d-flex gap-3 align-items-center">
              <?php foreach ($social as $icon => $url): ?>
                <li class="list-inline-item">
                  <a href="<?= $url ?>" target="_blank" rel="noopener" aria-label="<?= ucfirst(str_replace('-', ' ', $icon)) ?>">
                    <i class="fa-brands fa-<?= $icon ?>" aria-hidden="true"></i>
                  </a>
                </li>
              <?php endforeach; ?>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </footer>

  <a href="#" id="scroll-top" class="scroll-top" aria-label="Scroll to top">
    <i class="fa-solid fa-arrow-up" aria-hidden="true"></i>
  </a>

  <!-- Toast -->
  <div class="position-fixed bottom-0 end-0 p-3" style="z-index: 1080">
    <div id="newsletterToast" class="toast align-items-center text-bg-success border-0" role="alert" aria-live="assertive" aria-atomic="true">
      <div class="d-flex">
        <div id="newsletterToastMsg" class="toast-body"></div>
        <button type="button" class="btn-close me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
      </div>
    </div>
  </div>
</section>

<!-- Footer Scripts -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" defer></script>
<script src="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.js" defer></script>
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js" defer></script>

<script>
  document.addEventListener('DOMContentLoaded', function() {
    AOS.init({
      duration: 800,
      once: true,
      mirror: false,
      easing: 'ease-in-out'
    });

    // Scroll to Top
    const scrollBtn = document.getElementById('scroll-top');
    const toggleScrollBtn = () => {
      scrollBtn.classList.toggle('active', window.scrollY > 300);
    };
    window.addEventListener('scroll', toggleScrollBtn);
    toggleScrollBtn();

    // Sticky Navbar
    const nav = document.getElementById('navbar');
    if (nav) {
      const toggleStickyNav = () => nav.classList.toggle('fixed-top', window.scrollY > 0);
      window.addEventListener('scroll', toggleStickyNav, {
        passive: true
      });
      toggleStickyNav();
    }

    // Newsletter Toast
    const form = document.getElementById('newsletterForm');
    const toastEl = document.getElementById('newsletterToast');
    const toastMsg = document.getElementById('newsletterToastMsg');
    const toast = new bootstrap.Toast(toastEl);

    form.addEventListener('submit', function(e) {
      e.preventDefault();
      const email = form.querySelector('#newsletter-email').value.trim();
      const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

      toastEl.classList.remove('text-bg-success', 'text-bg-danger');

      if (!email || !emailPattern.test(email)) {
        toastEl.classList.add('text-bg-danger');
        toastMsg.textContent = 'Please enter a valid email address.';
        toast.show();
        return;
      }

      toastEl.classList.add('text-bg-success');
      toastMsg.textContent = 'Successfully subscribed to our newsletter!';
      toast.show();
      form.reset();
    });
  });
</script>
</body>