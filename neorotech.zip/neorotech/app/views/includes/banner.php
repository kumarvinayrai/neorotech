<section class="bg-primary-clip" aria-labelledby="banner-heading">
  <div class="container-fluid">
    <div class="row g-0 min-vh-75 align-items-stretch">
      
      <!-- Text Section -->
      <div class="col-lg-7 d-flex">
        <div class="d-flex flex-column justify-content-center align-items-center align-items-lg-start text-center text-lg-start w-100 px-4 px-lg-5 py-5 hero-single">
          <header class="hero-content w-100">
            <h1 id="banner-heading" class="hero-title" data-aos="fade-up">
              <?= htmlspecialchars($bannerHeading) ?>
            </h1>
            <p class="mb-0" data-aos="fade-up" data-aos-delay="100">
              <?= htmlspecialchars($bannerText) ?>
            </p>
          </header>
        </div>
      </div>

      <!-- Image Section -->
      <div class="col-lg-5 p-0" data-aos="fade-left" data-aos-delay="150">
        <img
          src="<?= htmlspecialchars($bannerImage) ?>"
          alt="News Banner featuring current highlights"
          title="News Banner"
          class="img-fluid object-fit-cover clip-img w-100 min-vh-75"
          loading="lazy"
          decoding="async"
        >
      </div>

    </div>
  </div>
</section>
