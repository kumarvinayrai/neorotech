<?php
declare(strict_types=1);

// Dynamic Content
$techDrivenData = [
  'sectionId'    => 'techDriven',
  'subheading'   => 'Our Philosophy',
  'title'        => 'Strategic <span>Digital</span> Excellence',
  'paragraphs'   => [
    'At <strong>Neorotech Solution</strong>, we are committed to fostering enduring client partnerships rooted in trust and collaboration. By understanding your unique goals and challenges, we co-create tailored solutions that drive measurable outcomes.',
    'Our dedicated team of professionals is focused on delivering exceptional service and consistently surpassing expectations.'
  ],
  'image' => [
    'src' => '/assets/images/about/about-01.jpg',
    'alt' => 'Philosophy Illustration'
  ]
];
?>

<section id="<?= htmlspecialchars($techDrivenData['sectionId']) ?>" class="position-relative py-5" aria-labelledby="<?= htmlspecialchars($techDrivenData['sectionId']) ?>-heading">
  <div class="container">
    <div class="row align-items-center g-5 lead lh-base">

      <!-- Text Column -->
      <div class="col-lg-6" data-aos="fade-right">
        <header>
          <?php if (!empty($techDrivenData['subheading'])): ?>
            <span class="text-uppercase fw-bold sub-heading-title mb-2">
              <?= htmlspecialchars($techDrivenData['subheading']) ?>
            </span>
          <?php endif; ?>
          <h2 id="<?= htmlspecialchars($techDrivenData['sectionId']) ?>-heading" class="heading-title my-3">
            <?= $techDrivenData['title'] ?>
          </h2>
        </header>

        <?php foreach ($techDrivenData['paragraphs'] as $para): ?>
          <p class="text-muted"><?= $para ?></p>
        <?php endforeach; ?>
      </div>

      <!-- Image Column -->
      <div class="col-lg-6">
        <div class="ms-xl-5">
          <figure class="zoom-effect mb-4" data-aos="zoom-in" data-aos-delay="200">
            <img
              src="<?= htmlspecialchars($techDrivenData['image']['src'], ENT_QUOTES, 'UTF-8') ?>"
              alt="<?= htmlspecialchars($techDrivenData['image']['alt']) ?>"
              class="img-fluid rounded-0 shadow-sm"
              loading="lazy"
            >
          </figure>
        </div>
      </div>

    </div>
  </div>
</section>
