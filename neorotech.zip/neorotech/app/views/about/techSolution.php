<?php
declare(strict_types=1);

// Section metadata
$techDrivenSection = [
  'subtitle'    => 'Driven by Technology, Built with Purpose',
  'title'       => 'How We Work <span>at Neorotech Solution</span>',
  'description' => 'We harness cutting-edge technology, data insights, and human-centered thinking to deliver agile, future-ready solutions that fuel business growth and societal impact.',
  // 'topShape' => removed
];

// Carousel slides — 3 features per slide
$techDrivenSlides = [
  [
    [
      'title'       => 'Philosophy of Purpose',
      'description' => 'Our philosophy blends innovation with intent—driving meaningful results while upholding transparency and trust.',
      'link'        => '#',
    ],
    [
      'title'       => 'Agile & Adaptive Methods',
      'description' => 'We move with speed and precision, adapting to market shifts while delivering consistent, high-quality solutions.',
      'link'        => '#',
    ],
    [
      'title'       => 'Client-Centric Collaboration',
      'description' => 'Our solutions are born from deep listening, collaborative discovery, and a commitment to exceeding expectations.',
      'link'        => '#',
    ],
  ],
  [
    [
      'title'       => 'Data-Driven Innovation',
      'description' => 'We extract powerful insights from data to create smarter, scalable strategies that unlock growth potential.',
      'link'        => '#',
    ],
    [
      'title'       => 'Ethical Engineering',
      'description' => 'We integrate integrity and accountability into our development lifecycle to ensure responsible tech delivery.',
      'link'        => '#',
    ],
    [
      'title'       => 'Future-Focused Delivery',
      'description' => 'Our teams remain ahead of the curve—embracing AI, automation, and cloud-native tools to drive impact.',
      'link'        => '#',
    ],
  ],
];
?>

<section id="techDriven" class="position-relative py-5 bg" aria-labelledby="techDriven-heading">

  <div class="container">

    <!-- Section Header -->
    <div class="row justify-content-center lead lh-base">
      <div class="col-12 text-center mb-4" data-aos="fade-up">
        <span class="text-uppercase fw-bold sub-heading-title mb-2">
          <?= htmlspecialchars($techDrivenSection['subtitle']) ?>
        </span>
        <h2 id="techDriven-heading" class="heading-title my-3">
          <?= $techDrivenSection['title'] ?>
        </h2>
        <p class="mb-4 text-start w-100">
          <?= htmlspecialchars($techDrivenSection['description']) ?>
        </p>
      </div>
    </div>

    <!-- Carousel -->
    <div id="techDrivenCarousel" class="carousel slide" data-bs-ride="carousel" data-bs-interval="5000" aria-label="Tech-driven philosophy carousel">
      <div class="carousel-inner">
        <?php foreach ($techDrivenSlides as $slideIndex => $slideGroup): ?>
          <div class="carousel-item <?= $slideIndex === 0 ? 'active' : '' ?>">
            <div class="row g-4">
              <?php foreach ($slideGroup as $itemIndex => $card): ?>
                <div class="col-12 col-sm-6 col-lg-4 d-flex" data-aos="zoom-in" data-aos-delay="<?= 100 * ($itemIndex + 1) ?>">
                  <a href="<?= htmlspecialchars($card['link']) ?>" class="text-decoration-none w-100" aria-label="<?= htmlspecialchars($card['title']) ?>">
                    <article class="card h-100 w-100 border-0 rounded-0 theme-card p-3 d-flex flex-column lead lh-base shadow-sm">
                      <div class="card-body d-flex flex-column">
                        <h3 class="card-title fs-5"><?= htmlspecialchars($card['title']) ?></h3>
                        <p class="card-text text-start"><?= htmlspecialchars($card['description']) ?></p>
                      </div>
                    </article>
                  </a>
                </div>
              <?php endforeach; ?>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    </div>

  </div>

</section>
