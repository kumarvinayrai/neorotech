<?php 
// Dynamic content for team section
$teamSection = [
  'id' => 'our-team-member',
  'bgClass' => 'py-5',
  'subheading' => 'Our Honorable Team Member',
  'title' => 'We’ve <span>Exclusive </span> Member, Meet our <span> Professionals</span>',
  'members' => [
    [
      'name' => 'Honey Mathil',
      'designation' => 'Managing Director',
      'image' => '/assets/images/images/tech/tech-1.jpg',
      'alt' => 'Honey Mathil',
      'delay' => 100
    ],
    [
      'name' => 'Vinay Rai',
      'designation' => 'IT Specialist',
      'image' => '/assets/images/images/tech/tech-2.jpg',
      'alt' => 'Vinay Rai',
      'delay' => 200
    ],
    [
      'name' => 'Varsh Rai',
      'designation' => 'Vice President - Product',
      'image' => '/assets/images/images/tech/tech-3.jpg',
      'alt' => 'Varsh Rai',
      'delay' => 300
    ],
    [
      'name' => 'Nikita Rai',
      'designation' => 'Vice President - Technology',
      'image' => '/assets/images/images/tech/tech-4.jpg',
      'alt' => 'Nikita Rai',
      'delay' => 400
    ]
  ]
];
?>

<section id="<?= htmlspecialchars($teamSection['id']) ?>" class="<?= htmlspecialchars($teamSection['bgClass']) ?>" aria-labelledby="<?= htmlspecialchars($teamSection['id']) ?>-heading">
  <div class="container">

    <!-- Section Header -->
    <div class="row mb-4">
      <div class="col text-center">
        <span class="text-uppercase fw-bold sub-heading-title mb-2 d-inline-block" data-aos="fade-down">
          <?= htmlspecialchars($teamSection['subheading']) ?>
        </span>
        <h2 class="heading-title my-3" id="<?= htmlspecialchars($teamSection['id']) ?>-heading" data-aos="fade-down" data-aos-delay="100">
          <?= $teamSection['title'] ?>
        </h2>
      </div>
    </div>

    <!-- Team Members -->
    <div class="row row-cols-1 row-cols-sm-2 row-cols-xl-4 g-4" data-aos="fade-up" data-aos-delay="50">
      <?php foreach ($teamSection['members'] as $member): ?>
        <div class="col" data-aos="fade-up" data-aos-delay="<?= (int) $member['delay'] ?>">
          <div class="card border-0 shadow-sm rounded-0 h-100 text-center p-3">
            <img 
              src="<?= htmlspecialchars($member['image'], ENT_QUOTES, 'UTF-8') ?>" 
              alt="<?= htmlspecialchars($member['alt']) ?>" 
              class="img-fluid rounded-circle mx-auto mb-3 w-75 w-md-50"
              loading="lazy"
            >
            <div class="card-body p-0">
              <h6 class="fw-semibold mb-1 fs-6 fs-md-5"><?= htmlspecialchars($member['name']) ?></h6>
              <p class="text-muted mb-0 small fs-6"><?= htmlspecialchars($member['designation']) ?></p>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>

  </div>
</section>
