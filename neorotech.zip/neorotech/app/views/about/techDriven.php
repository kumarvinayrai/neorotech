<?php
declare(strict_types=1);

// Section content
$techSection = [
  'title' => 'At <strong>Neorotech Solution</strong>, we don’t merely deliver technology solutions—we drive business transformation through innovation, precision, and exceptional expertise. We go beyond software development, fostering lasting partnerships and shaping the future of technology by redefining what’s possible.',
  'subtitle' => 'How We Work: Driven by Technology, with Embedded Purpose',
  'description' => [
    'At <strong>Neorotech Solution</strong>, our philosophy is simple: to harness the power of technology to drive positive change and create value for our clients and society. We believe in the transformative potential of data-driven insights, innovation, and collaboration to solve complex challenges and achieve sustainable growth.',
    'Our approach is rooted in transparency, integrity, and a commitment to excellence. We believe in listening to our clients, understanding their needs, and delivering tailored solutions that exceed expectations. With a focus on continuous improvement and agility, we adapt to changing market dynamics and embrace new technologies to stay ahead of the curve.',
  ],
  'image' => [
    'src' => '/assets/images/images/tech/tech-1.jpg',
    'alt' => 'Illustration representing our technology-driven philosophy',
  ]
];
?>

<section id="techDriven" class="position-relative py-5" aria-labelledby="techDriven-heading">
  <div class="container" data-aos="fade-up" data-aos-delay="50">

    <!-- Section Intro -->
    <div class="row mb-5">
      <div class="col text-center">
        <h2 class="fw-semibold fs-4 lh-base" id="techDriven-heading">
          <?= $techSection['title'] ?>
        </h2>
      </div>
    </div>

    <!-- Content Row -->
    <div class="row align-items-center gy-4">

      <!-- Text Column -->
      <div class="col-xl-6" data-aos="fade-right" data-aos-delay="100">
        <div class="pe-xl-5">
          <h3 class="mb-3 fw-bold fs-4">
            <?= htmlspecialchars($techSection['subtitle']) ?>
          </h3>
          <?php foreach ($techSection['description'] as $para): ?>
            <p><?= $para ?></p>
          <?php endforeach; ?>
        </div>
      </div>

      <!-- Image Column -->
      <div class="col-xl-6" data-aos="fade-left" data-aos-delay="200">
        <img 
          src="<?= htmlspecialchars($techSection['image']['src']) ?>" 
          alt="<?= htmlspecialchars($techSection['image']['alt']) ?>" 
          class="img-fluid rounded-3 shadow" 
          loading="lazy"
        >
      </div>

    </div>
  </div>
</section>
