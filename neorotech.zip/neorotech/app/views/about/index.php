<?php
$bannerImage = '/assets/images/about/about-02.jpg';
$bannerHeading = 'About Us';
$bannerText = 'Turning Creative Ideas into Real-World Solutions with Custom Software That Drives Lasting Impact and Growth.';
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
include __DIR__ . '/../includes/banner.php';
require_once __DIR__ . '/aboutContent.php';
require_once __DIR__ . '/techSolution.php';
require_once __DIR__ . '/teamMember.php';
require_once __DIR__ . '/../home/partner.php';
include __DIR__ . '/../includes/footer.php';
?> 
