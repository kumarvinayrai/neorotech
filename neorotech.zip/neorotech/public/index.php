<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Get URI path (no query string)
$uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

// Remove trailing slashes
$uri = rtrim($uri, '/');

// Default route to /home/home
if ($uri === '' || $uri === '/') {
    $uri = '/home/home';
}

// Correct folder path (must match exactly)
$baseViewPath = realpath(__DIR__ . '/../app/views');
$viewFilePath = $baseViewPath . $uri . '.php';

// Resolve & validate
$realPath = realpath($viewFilePath);
if ($realPath && strpos($realPath, $baseViewPath) === 0) {
    require_once $realPath;
} else {
    http_response_code(404);
    echo "<h1>404 - Page Not Found</h1>";
}
